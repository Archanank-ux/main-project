import { useState } from "react";
import { MessageSquareHeart, Star, CheckCircle2 } from "lucide-react";
import { feedbackAPI, ApiError } from "../services/api";
import Card from "./Card";
import Button from "./Button";

const CATEGORIES = ["Accuracy", "Clarity", "Speed", "Missing information", "Other"];

export default function FeedbackForm({ analysisId }) {
  const [helpful, setHelpful] = useState(null);
  const [explanationClear, setExplanationClear] = useState(null);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [category, setCategory] = useState("");
  const [status, setStatus] = useState("idle"); // idle | loading | done | duplicate | error
  const [error, setError] = useState("");

  async function submit() {
    if (helpful === null || explanationClear === null) {
      setError("Please answer both required questions.");
      return;
    }
    setError("");
    setStatus("loading");
    try {
      await feedbackAPI.submit({
        analysis_id: analysisId,
        helpful,
        explanation_clear: explanationClear,
        rating: rating || undefined,
        comment: comment.trim() || undefined,
        category: category || undefined,
      });
      setStatus("done");
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setStatus("duplicate");
        return;
      }
      setError(err.message || "Could not save feedback. Please try again.");
      setStatus("error");
    }
  }

  if (status === "done") {
    return (
      <Card title="Help Us Improve">
        <div className="feedback-done"><CheckCircle2 size={18} /> Thanks — your feedback was saved.</div>
      </Card>
    );
  }
  if (status === "duplicate") {
    return (
      <Card title="Help Us Improve">
        <div className="feedback-done"><CheckCircle2 size={18} /> You already submitted feedback for this analysis.</div>
      </Card>
    );
  }

  return (
    <Card title="Help Us Improve">
      <div className="eyebrow"><MessageSquareHeart size={14} /> YOUR FEEDBACK</div>
      <div className="feedback-row">
        <span>Was this recommendation helpful?</span>
        <div className="segmented">
          <button type="button" className={helpful === true ? "selected" : ""} onClick={() => setHelpful(true)}>Yes</button>
          <button type="button" className={helpful === false ? "selected" : ""} onClick={() => setHelpful(false)}>No</button>
        </div>
      </div>
      <div className="feedback-row">
        <span>Was the explanation clear?</span>
        <div className="segmented">
          <button type="button" className={explanationClear === true ? "selected" : ""} onClick={() => setExplanationClear(true)}>Yes</button>
          <button type="button" className={explanationClear === false ? "selected" : ""} onClick={() => setExplanationClear(false)}>No</button>
        </div>
      </div>
      <div className="feedback-row">
        <span>Rating (optional)</span>
        <div className="star-row">
          {[1, 2, 3, 4, 5].map((n) => (
            <button type="button" key={n} onClick={() => setRating(n === rating ? 0 : n)} aria-label={`${n} star`}>
              <Star size={18} fill={n <= rating ? "currentColor" : "none"} />
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <label>Category (optional)</label>
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">Select category</option>
          {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>
      <div className="field">
        <label>Comment (optional)</label>
        <textarea rows={3} value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Tell us more…" />
      </div>
      {error && <div className="field-error" style={{ marginBottom: 10 }}>{error}</div>}
      <Button variant="primary" loading={status === "loading"} onClick={submit}>Submit Feedback</Button>
    </Card>
  );
}
