import { useState } from "react";
import { Eye, EyeOff, AlertCircle } from "lucide-react";

export default function PasswordInput({ label, required, error, id, ...rest }) {
  const [visible, setVisible] = useState(false);
  const inputId = id || rest.name;
  return (
    <div className="field">
      {label && (
        <label htmlFor={inputId} className={required ? "field-required" : ""}>
          {label}
        </label>
      )}
      <div className="password-field-wrap">
        <input
          id={inputId}
          type={visible ? "text" : "password"}
          className={error ? "invalid" : ""}
          aria-invalid={!!error}
          {...rest}
        />
        <button
          type="button"
          className="password-toggle"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? "Hide password" : "Show password"}
          tabIndex={-1}
        >
          {visible ? <EyeOff size={17} /> : <Eye size={17} />}
        </button>
      </div>
      {error && (
        <div className="field-error">
          <AlertCircle size={13} /> {error}
        </div>
      )}
    </div>
  );
}
