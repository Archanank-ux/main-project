export default function Card({ title, children, className = "", ...rest }) {
  return (
    <div className={`card ${className}`} {...rest}>
      {title && <div className="card-title">{title}</div>}
      {children}
    </div>
  );
}
