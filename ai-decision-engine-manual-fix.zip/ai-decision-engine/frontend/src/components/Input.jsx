import { AlertCircle } from "lucide-react";

export default function Input({ label, required, error, hint, valid, id, ...rest }) {
  const inputId = id || rest.name;
  return (
    <div className="field">
      {label && (
        <label htmlFor={inputId} className={required ? "field-required" : ""}>
          {label}
        </label>
      )}
      <input
        id={inputId}
        className={error ? "invalid" : valid ? "valid" : ""}
        aria-invalid={!!error}
        aria-describedby={error ? `${inputId}-error` : undefined}
        {...rest}
      />
      {error && (
        <div className="field-error" id={`${inputId}-error`}>
          <AlertCircle size={13} /> {error}
        </div>
      )}
      {!error && hint && <div className="field-hint">{hint}</div>}
    </div>
  );
}
