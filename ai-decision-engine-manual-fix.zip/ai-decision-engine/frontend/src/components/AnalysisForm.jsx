import { useState } from "react";
import { Link as LinkIcon, Sparkles, Globe2, MousePointer2, Plus, X } from "lucide-react";
import Button from "./Button";

const URL_RE = /^https?:\/\/[^\s/$.?#].[^\s]*$/i;

const PRIORITY_OPTIONS = [
  { value: "quality", label: "Quality" },
  { value: "price", label: "Price" },
  { value: "durability", label: "Durability" },
];

const DURATION_OPTIONS = [
  { value: "short_term", label: "Short-term use" },
  { value: "long_term", label: "Long-term use" },
];

export default function AnalysisForm({ onSubmit, loading, compact = false }) {
  const [method, setMethod] = useState("manual");
  const [showSecond, setShowSecond] = useState(false);
  const [form, setForm] = useState({
    url: "", priority: "", duration: "", second_url: "",
  });
  const [errors, setErrors] = useState({});

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
    if (errors[field]) setErrors((e) => ({ ...e, [field]: null }));
  }

  function validate() {
    const errs = {};
    if (!form.url.trim()) errs.url = "Product URL is required.";
    else if (!URL_RE.test(form.url.trim())) errs.url = "Please enter a valid product URL.";
    if (!form.priority) errs.priority = "Please choose what matters most to you.";
    if (!form.duration) errs.duration = "Please choose how long you plan to use this product.";
    if (showSecond && form.second_url.trim()) {
      if (!URL_RE.test(form.second_url.trim())) errs.second_url = "Please enter a valid second product URL.";
      else if (form.second_url.trim().toLowerCase() === form.url.trim().toLowerCase()) {
        errs.second_url = "The second URL is identical to the first product URL.";
      }
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!validate() || loading) return;
    const second_url = showSecond ? form.second_url.trim() : "";
    onSubmit({
      url: form.url.trim(),
      priority: form.priority,
      duration: form.duration,
      second_url,
      analysis_method: method,
    });
  }

  const isCompare = showSecond && form.second_url.trim();

  return (
    <form onSubmit={handleSubmit}>
      <div className="analysis-methods">
        <button type="button" className={`method-card method-card-main ${method === "manual" ? "selected" : ""}`} onClick={() => setMethod("manual")}>
          <MousePointer2 size={22} />
          <span><strong>Manual Analysis</strong><small>Detailed review-trust analysis using the existing trained 12-feature model.</small></span>
        </button>
        <button type="button" className={`method-card method-card-small ${method === "selenium" ? "selected" : ""}`} onClick={() => setMethod("selenium")}>
          <Globe2 size={18} />
          <span><strong>Selenium Analysis</strong><small>Rendered page analysis using Selenium for dynamic product data.</small></span>
        </button>
      </div>

      <div className="url-input-wrap">
        <LinkIcon size={16} />
        <input placeholder="https://www.amazon.in/..." value={form.url} onChange={(e) => update("url", e.target.value)} className={errors.url ? "invalid" : ""} aria-label="Product URL" />
      </div>
      {errors.url && <div className="field-error" style={{ marginTop: -10, marginBottom: 14 }}>{errors.url}</div>}
      <div className="field-hint" style={{ marginTop: 8, marginBottom: 16 }}>
        Supports Amazon, Flipkart, Myntra, Meesho, Croma and Nykaa product pages.
      </div>

      {!compact && (
        <>
          <div className="personal-head">
            <h3>Your Preferences</h3>
            <span>These shape the recommendation but never change the trained model's own prediction.</span>
          </div>
          <div className="grid-2">
            <div className="field">
              <label>What matters most to you?</label>
              <div className="segmented">
                {PRIORITY_OPTIONS.map((opt) => (
                  <button type="button" key={opt.value} className={form.priority === opt.value ? "selected" : ""} onClick={() => update("priority", opt.value)}>
                    {opt.label}
                  </button>
                ))}
              </div>
              {errors.priority && <div className="field-error">{errors.priority}</div>}
            </div>
            <div className="field">
              <label>How long do you plan to use this product?</label>
              <div className="segmented">
                {DURATION_OPTIONS.map((opt) => (
                  <button type="button" key={opt.value} className={form.duration === opt.value ? "selected" : ""} onClick={() => update("duration", opt.value)}>
                    {opt.label}
                  </button>
                ))}
              </div>
              {errors.duration && <div className="field-error">{errors.duration}</div>}
            </div>
          </div>

          {!showSecond ? (
            <button type="button" className="btn btn-ghost btn-sm" style={{ marginTop: 10 }} onClick={() => setShowSecond(true)}>
              <Plus size={14} /> Add another product to compare
            </button>
          ) : (
            <div style={{ marginTop: 16 }}>
              <div className="personal-head" style={{ marginBottom: 10 }}>
                <h3>Second Product (optional)</h3>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setShowSecond(false); update("second_url", ""); }}>
                  <X size={14} /> Remove
                </button>
              </div>
              <div className="url-input-wrap">
                <LinkIcon size={16} />
                <input placeholder="https://www.flipkart.com/..." value={form.second_url} onChange={(e) => update("second_url", e.target.value)} className={errors.second_url ? "invalid" : ""} aria-label="Second product URL" />
              </div>
              {errors.second_url && <div className="field-error" style={{ marginTop: -10, marginBottom: 10 }}>{errors.second_url}</div>}
            </div>
          )}
        </>
      )}

      <Button type="submit" variant="primary" size="lg" className="btn-block" loading={loading} disabled={loading} style={{ marginTop: 18 }}>
        {!loading && <Sparkles size={17} />}
        {loading ? "Analyzing…" : isCompare ? "Analyze & Compare" : "Analyze Product"}
      </Button>
    </form>
  );
}
