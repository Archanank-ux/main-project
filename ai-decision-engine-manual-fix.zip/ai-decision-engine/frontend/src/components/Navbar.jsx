import { useNavigate, useLocation } from "react-router-dom";
import { Brain, LogOut } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import Button from "./Button";

export default function Navbar() {
  const { user, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  async function handleLogout() {
    await logout();
    toast("You've been signed out.", "success");
    navigate("/");
  }

  const guestLinks = [
    ["/", "Home"],
    ["/#how-it-works", "How It Works"],
    ["/#features", "Features"],
  ];
  const userLinks = [
    ["/dashboard", "Dashboard"],
    ["/analyze", "Analyze"],
  ];

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <div className="brand" onClick={() => navigate(user ? "/dashboard" : "/")}>
          <span className="brand-mark">
            <Brain size={16} />
          </span>
          AI Decision Engine
        </div>
        <nav className="nav-links">
          {(user ? userLinks : guestLinks).map(([path, label]) => (
            <button
              key={path}
              className={`nav-link ${location.pathname === path ? "active" : ""}`}
              onClick={() => {
                if (path.startsWith("/#")) {
                  navigate("/");
                  setTimeout(() => document.getElementById(path.split("#")[1])?.scrollIntoView({ behavior: "smooth" }), 50);
                } else {
                  navigate(path);
                }
              }}
            >
              {label}
            </button>
          ))}
        </nav>
        <div className="nav-actions">
          {user ? (
            <>
              <button className="nav-link" onClick={() => navigate("/profile")}>{user.name}</button>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut size={14} /> Logout
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" size="sm" onClick={() => navigate("/login")}>Login</Button>
              <Button variant="primary" size="sm" onClick={() => navigate("/register")}>Register</Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
