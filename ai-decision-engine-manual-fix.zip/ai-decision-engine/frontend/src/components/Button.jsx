export default function Button({
  children,
  variant = "primary",
  size,
  loading = false,
  className = "",
  ...rest
}) {
  const classes = ["btn", `btn-${variant}`, size ? `btn-${size}` : "", className]
    .filter(Boolean)
    .join(" ");
  return (
    <button className={classes} disabled={loading || rest.disabled} {...rest}>
      {loading && <span className="spinner-ring" />}
      {children}
    </button>
  );
}
