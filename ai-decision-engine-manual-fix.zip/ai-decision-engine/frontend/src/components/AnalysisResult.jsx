import { useNavigate } from "react-router-dom";
import {
  BadgeCheck, Gauge, ExternalLink, SkipForward, Clock3, ShieldCheck, ThumbsUp, ThumbsDown,
  Bot, Star, Zap, BarChart3, Lightbulb, AlertTriangle, HelpCircle, Trophy, ArrowLeftRight,
} from "lucide-react";
import Card from "./Card";
import Button from "./Button";
import FeedbackForm from "./FeedbackForm";
import { useToast } from "../context/ToastContext";

const ACTIONS = {
  buy: { label: "Go to Product", icon: ExternalLink, variant: "primary" },
  skip: { label: "Skip This Product", icon: SkipForward, variant: "outline" },
  do_not_buy: { label: "Skip This Product", icon: SkipForward, variant: "outline" },
  wait: { label: "Wait & Recheck", icon: Clock3, variant: "outline" },
};

function decisionLabel(decision) {
  const key = (decision || "").trim().toLowerCase();
  if (key === "skip") return "DO NOT BUY";
  if (!key) return "INSUFFICIENT DATA";
  return decision.toUpperCase();
}

function SingleProductBlock({ result, url, label }) {
  const decisionKey = (result.decision || "").trim().toLowerCase();
  const action = ACTIONS[decisionKey];
  const product = result.product || {};
  const review = result.review_analysis || {};
  const isSelenium = result.analysis_method === "selenium";
  const seleniumFeatures = review.features || {};
  const explain = result.explain || {};
  const showRawVsAdjusted = result.decision_raw && result.decision && result.decision_raw !== result.decision;
  const toast = useToast();

  function handleAction() {
    if (decisionKey === "buy") window.open(url, "_blank", "noopener,noreferrer");
    else toast("Saved.", "info");
  }

  return (
    <div className={`decision-${decisionKey || "insufficient_data"}`}>
      <div className="result-hero">
        {label && <div className="result-hero-label">{label}</div>}
        <div className="result-hero-label">{isSelenium ? "Selenium" : "Manual"} Mode</div>
        <div className="result-hero-decision">{decisionLabel(result.decision)}</div>
        <div className="confidence-pill"><Gauge size={15} /> ML Confidence: {result.confidence != null ? `${Math.round(result.confidence * 100)}%` : "Not available"}</div>

        {showRawVsAdjusted && (
          <p style={{ color: "rgba(255,255,255,0.85)", maxWidth: 560, margin: "8px auto 0", fontSize: 13.5 }}>
            Original model prediction: <strong>{decisionLabel(result.decision_raw)}</strong> — adjusted to{" "}
            <strong>{decisionLabel(result.decision)}</strong> based on your preferences (see "Why This Recommendation?" below).
          </p>
        )}

        {action && <div style={{ marginTop: 22 }}><Button variant={action.variant} size="lg" onClick={handleAction}><action.icon size={17} /> {action.label}</Button></div>}
      </div>

      {isSelenium ? (
        <div className="result-metric-grid">
          <div className="result-metric"><span>Price</span><strong>{product.price != null ? `₹${Number(product.price).toLocaleString("en-IN")}` : "Not found"}</strong></div>
          <div className="result-metric"><span>Rating</span><strong>{product.rating ? `${Number(product.rating).toFixed(1)}/5` : "Not found"}</strong></div>
          <div className="result-metric"><span>Rating Count</span><strong>{Number(seleniumFeatures.rating_count || product.review_count || 0).toLocaleString("en-IN")}</strong></div>
          <div className="result-metric"><span>Positive Reviews</span><strong>{seleniumFeatures.positive_review_pct ?? 0}%</strong></div>
        </div>
      ) : (
        <div className="result-metric-grid">
          <div className="result-metric"><span>Price</span><strong>{product.price != null ? `₹${Number(product.price).toLocaleString("en-IN")}` : "Not found"}</strong></div>
          <div className="result-metric"><span>Review Trust Score</span><strong>{review.review_trust_score != null ? `${Math.round(review.review_trust_score)}/100` : "Not available"}</strong></div>
          <div className="result-metric"><span>Rating</span><strong>{product.rating ? `${Number(product.rating).toFixed(1)}/5` : "Not found"}</strong></div>
          <div className="result-metric"><span>Reviews</span><strong>{review.features?.review_count ?? product.review_count ?? 0}</strong></div>
        </div>
      )}

      {(result.pros?.length || result.cons?.length) ? (
        <div className="grid-2">
          {result.pros?.length ? (
            <Card title="Pros">
              <ul className="pros-cons-list">{result.pros.map((x, i) => <li key={i}><ThumbsUp size={15} />{x}</li>)}</ul>
            </Card>
          ) : null}
          {result.cons?.length ? (
            <Card title="Cons">
              <ul className="pros-cons-list">{result.cons.map((x, i) => <li key={i}><ThumbsDown size={15} />{x}</li>)}</ul>
            </Card>
          ) : null}
        </div>
      ) : null}

      <Card title="Why This Recommendation?">
        <div className="eyebrow"><Lightbulb size={14} /> EXPLAINABLE AI DECISION CARD</div>
        <p className="text-muted" style={{ marginTop: 6 }}>Final recommendation: <strong>{decisionLabel(result.decision)}</strong></p>

        {explain.signals?.length ? (
          <div className="explain-block explain-positive">
            <strong><ThumbsUp size={14} /> Positive signals</strong>
            <ul>{explain.signals.map((s, i) => <li key={i}>{s}</li>)}</ul>
          </div>
        ) : null}

        {explain.warnings?.length ? (
          <div className="explain-block explain-warning">
            <strong><AlertTriangle size={14} /> Warning signs</strong>
            <ul>{explain.warnings.map((w, i) => <li key={i}>{w}</li>)}</ul>
          </div>
        ) : null}

        {explain.missing?.length ? (
          <div className="explain-block explain-missing">
            <strong><HelpCircle size={14} /> Missing information / limitations</strong>
            <ul>{explain.missing.map((m, i) => <li key={i}>{m}</li>)}</ul>
          </div>
        ) : null}

        {explain.priority_explanation && (
          <div className="explain-block explain-priority">
            <strong>Priority-specific explanation</strong>
            <p>{explain.priority_explanation}</p>
          </div>
        )}
      </Card>

      <Card title="Product Information">
        <div className="detail-row"><span className="label">Name</span><span className="value">{product.name || "—"}</span></div>
        <div className="detail-row"><span className="label">Category</span><span className="value">{product.category || "—"}</span></div>
        <div className="detail-row"><span className="label">URL</span><span className="value">{url}</span></div>
      </Card>
    </div>
  );
}

function ComparisonBlock({ result, analysis }) {
  const comparison = result.comparison;
  const a = comparison.product_a;
  const b = comparison.product_b;
  const summary = comparison.summary || {};
  const urlB = analysis.result?.comparison?.product_b?.product?.url;

  const winnerLabel = summary.winner === "product_a" ? "Product A" : summary.winner === "product_b" ? "Product B" : null;

  return (
    <>
      <Card title="Which Product Better Matches Your Priorities?">
        <div className="eyebrow"><Trophy size={14} /> COMPARISON SUMMARY</div>
        {winnerLabel ? (
          <p style={{ marginTop: 8 }}><strong>{winnerLabel}</strong> better matches your priority ({summary.priority || "—"}). {summary.winner_reason}</p>
        ) : (
          <p style={{ marginTop: 8 }} className="text-muted">{summary.winner_reason || "There is no sufficiently supported winner based on the available evidence."}</p>
        )}
      </Card>

      <Card title="Side-by-Side Comparison">
        <div className="eyebrow"><ArrowLeftRight size={14} /> COMPARISON TABLE</div>
        <table className="compare-table">
          <thead><tr><th></th><th>Product A</th><th>Product B</th></tr></thead>
          <tbody>
            <tr><td>Decision</td><td>{decisionLabel(a.decision)}</td><td>{decisionLabel(b.decision)}</td></tr>
            <tr><td>Price</td><td>{a.product?.price != null ? `₹${Number(a.product.price).toLocaleString("en-IN")}` : "—"}</td><td>{b.product?.price != null ? `₹${Number(b.product.price).toLocaleString("en-IN")}` : "—"}</td></tr>
            <tr><td>Rating</td><td>{a.product?.rating ? `${Number(a.product.rating).toFixed(1)}/5` : "—"}</td><td>{b.product?.rating ? `${Number(b.product.rating).toFixed(1)}/5` : "—"}</td></tr>
            <tr><td>Confidence</td><td>{a.confidence != null ? `${Math.round(a.confidence * 100)}%` : "—"}</td><td>{b.confidence != null ? `${Math.round(b.confidence * 100)}%` : "—"}</td></tr>
          </tbody>
        </table>
      </Card>

      <div className="grid-2">
        <SingleProductBlock result={a} url={analysis.product_url} label="Product A" />
        <SingleProductBlock result={b} url={urlB || ""} label="Product B" />
      </div>
    </>
  );
}

export default function AnalysisResult({ analysis }) {
  const { result, created_at } = analysis;
  const navigate = useNavigate();
  const isComparison = !!result.is_comparison && !!result.comparison;

  return (
    <div className="results-layout">
      <div className="results-main">
        {isComparison ? (
          <ComparisonBlock result={result} analysis={analysis} />
        ) : (
          <SingleProductBlock result={result} url={analysis.product_url} />
        )}

        <FeedbackForm analysisId={analysis.id} />
      </div>

      <div className="sidebar-stack">
        <Card title="Model Status">
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <BadgeCheck size={18} style={{ color: "var(--success)" }} />
            <span className="pill pill-success">{result.analysis_method === "selenium" ? "4-feature Selenium model" : "12-feature Manual model"}</span>
          </div>
        </Card>
        <Card title="Analysis Type">
          <p className="text-muted" style={{ fontSize: 13.5 }}>{isComparison ? "Two-product comparison" : "Single product analysis"}</p>
        </Card>
        <Card title="Analyzed">
          <p className="text-muted" style={{ fontSize: 13.5 }}>{new Date(created_at).toLocaleString()}</p>
        </Card>
      </div>
    </div>
  );
}
