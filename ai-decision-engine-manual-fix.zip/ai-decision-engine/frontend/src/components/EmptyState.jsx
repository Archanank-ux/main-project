export default function EmptyState({ icon: Icon, title, message, action }) {
  return (
    <div className="state-block">
      {Icon && (
        <div className="state-icon">
          <Icon size={24} />
        </div>
      )}
      <h3>{title}</h3>
      {message && <p>{message}</p>}
      {action}
    </div>
  );
}
