export default function LoadingSpinner({ label = "Loading…" }) {
  return (
    <div className="page-loader">
      <div className="big-ring" />
      {label && <p className="text-muted">{label}</p>}
    </div>
  );
}
