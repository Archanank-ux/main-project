import { useNavigate } from "react-router-dom";
import { PackageSearch, Trash2 } from "lucide-react";
import EmptyState from "./EmptyState";
import { analysisAPI } from "../services/api";
import { useToast } from "../context/ToastContext";

export default function HistoryTable({ items, onDeleted }) {
  const navigate = useNavigate();
  const toast = useToast();

  if (!items || items.length === 0) {
    return (
      <EmptyState
        icon={PackageSearch}
        title="No analyses yet"
        message="Run your first product analysis to see it show up here."
      />
    );
  }

  async function handleDelete(e, id) {
    e.stopPropagation();
    if (!window.confirm("Delete this analysis? This can't be undone.")) return;
    try {
      await analysisAPI.deleteOne(id);
      toast("Analysis deleted.", "success");
      onDeleted?.(id);
    } catch (err) {
      toast(err.message || "Could not delete this analysis.", "error");
    }
  }

  return (
    <table className="history-table">
      <thead>
        <tr>
          <th>Product</th>
          <th>Date</th>
          <th>Status</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr key={item.id} className="clickable" onClick={() => navigate(`/result/${item.id}`)}>
            <td>{item.product_name || item.product_url}</td>
            <td>{new Date(item.created_at).toLocaleDateString()}</td>
            <td>
              <span className={`pill ${item.status === "completed" ? "pill-success" : "pill-warning"}`}>
                {item.status}
              </span>
            </td>
            <td>
              <button
                className="btn btn-ghost btn-sm"
                onClick={(e) => handleDelete(e, item.id)}
                aria-label="Delete analysis"
                title="Delete analysis"
              >
                <Trash2 size={15} />
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
