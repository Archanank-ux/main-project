export default function Footer() {
  return (
    <footer className="footer container">
      <div className="footer-grid">
        <div className="footer-brand">
          <div style={{ fontWeight: 800, fontFamily: "var(--font-display)" }}>AI Decision Engine</div>
          <p>Turning complex product data into clear, actionable insights.</p>
        </div>
        <div className="footer-col">
          <h5>Product</h5>
          <a>How It Works</a>
          <a>Features</a>
          <a>Dashboard</a>
        </div>
        <div className="footer-col">
          <h5>Company</h5>
          <a>About</a>
          <a>Contact</a>
        </div>
        <div className="footer-col">
          <h5>Legal</h5>
          <a>Privacy Policy</a>
          <a>Terms</a>
        </div>
      </div>
      <div className="footer-bottom">© {new Date().getFullYear()} AI Decision Engine. All rights reserved.</div>
    </footer>
  );
}
