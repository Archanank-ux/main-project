/**
 * Centralized API layer. Components call authAPI / analysisAPI — never
 * fetch() directly — so the base URL, auth header, and error shape stay
 * in one place.
 */
const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const TOKEN_KEY = "ai_decision_engine_token";

export function getToken() {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* ignore storage errors */
  }
}

export class ApiError extends Error {
  constructor(message, status, errors) {
    super(message);
    this.status = status;
    this.errors = errors || null;
  }
}

async function request(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth) {
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  let res;
  try {
    res = await fetch(`${API_URL}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError("Unable to connect to the analysis service. Please try again.", 0);
  }

  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }

  if (!res.ok) {
    if (res.status === 401) setToken(null);
    const message =
      (data && (data.message || (data.errors && "Please check the highlighted fields."))) ||
      "Something went wrong. Please try again.";
    throw new ApiError(message, res.status, data && data.errors);
  }

  return data;
}

export const authAPI = {
  register: (payload) => request("/auth/register", { method: "POST", body: payload, auth: false }),
  login: async (payload) => {
    const data = await request("/auth/login", { method: "POST", body: payload, auth: false });
    setToken(data.access_token);
    return data;
  },
  me: () => request("/auth/me"),
  logout: async () => {
    try {
      await request("/auth/logout", { method: "POST" });
    } finally {
      setToken(null);
    }
  },
  isLoggedIn: () => !!getToken(),
};

export const productAPI = {
  preview: (url) => request("/analysis/product-preview", { method: "POST", body: { url } }),
};

export const analysisAPI = {
  analyze: (payload) => request("/analysis/analyze", { method: "POST", body: payload }),
  compare: (payload) => request("/analysis/compare", { method: "POST", body: payload }),
  history: () => request("/analysis/history"),
  stats: () => request("/analysis/stats"),
  getOne: (id) => request(`/analysis/${id}`),
  deleteOne: (id) => request(`/analysis/${id}`, { method: "DELETE" }),
};

export const feedbackAPI = {
  submit: (payload) => request("/feedback", { method: "POST", body: payload }),
};

export const healthAPI = {
  check: () => request("/health", { auth: false }),
};
