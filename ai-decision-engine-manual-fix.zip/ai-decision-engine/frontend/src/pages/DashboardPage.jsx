import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { BarChart3, CheckCircle2, ListChecks, Sparkles, ArrowRight } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { analysisAPI } from "../services/api";
import StatCard from "../components/StatCard";
import HistoryTable from "../components/HistoryTable";
import Card from "../components/Card";
import Button from "../components/Button";
import LoadingSpinner from "../components/LoadingSpinner";

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [history, setHistory] = useState(null);

  useEffect(() => {
    analysisAPI.stats().then((d) => setStats(d.stats)).catch(() => setStats({ total_analyses: 0, successful_analyses: 0, recent_analyses: [] }));
    analysisAPI.history().then((d) => setHistory(d.history)).catch(() => setHistory([]));
  }, []);

  if (!stats || !history) return <LoadingSpinner label="Loading your dashboard…" />;

  return (
    <div className="container section-tight">
      <div className="home-split">
        <div className="home-left">
          <div className="brand-mark-large">AI</div>
          <h1>AI Product Decision Engine</h1>
          <p>Smarter Choices. Better Purchases.</p>
        </div>
        <div className="home-right">
          <div className="dash-welcome">
            <div>
              <span className="eyebrow">WELCOME</span>
              <h2>{user?.name || user?.email || "User"}</h2>
              <p>Analyze Amazon products and make clearer buying decisions.</p>
            </div>
            <Button variant="primary" size="lg" onClick={() => navigate("/analyze")}>
              <Sparkles size={17} /> Analyze Product <ArrowRight size={16} />
            </Button>
          </div>
          <div className="home-feature-grid">
            <div className="home-feature-card"><h3>Analyze Products</h3><p>Get product specifications from an Amazon product page.</p></div>
            <div className="home-feature-card"><h3>Analysis History</h3><p>View your previous product analyses and decisions.</p></div>
            <div className="home-feature-card"><h3>Budget Check</h3><p>See whether the product fits the budget you enter.</p></div>
            <div className="home-feature-card"><h3>Review Insights</h3><p>Manual mode checks review trust and suspicious reviews.</p></div>
            <div className="home-feature-card"><h3>Pros & Cons</h3><p>Manual mode shows evidence-based positive and negative findings.</p></div>
            <div className="home-feature-card"><h3>Personal Recommendation</h3><p>Use budget, intended usage and Price or Quality priority.</p></div>
            <div className="home-feature-card"><h3>Key Insights</h3><p>See the main reasons behind the final decision.</p></div>
          </div>
        </div>
      </div>

      <div className="stat-grid">
        <StatCard icon={BarChart3} value={stats.total_analyses} label="Total Analyses" />
        <StatCard icon={CheckCircle2} value={stats.successful_analyses} label="Successful Analyses" />
        <StatCard icon={ListChecks} value={stats.recent_analyses.length} label="Recent Analyses" />
      </div>

      <Card title="Analysis History">
        <HistoryTable items={history} onDeleted={(id) => setHistory((h) => h.filter((item) => item.id !== id))} />
      </Card>
    </div>
  );
}
