import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { analysisAPI, ApiError } from "../services/api";
import { useToast } from "../context/ToastContext";
import Card from "../components/Card";
import AnalysisForm from "../components/AnalysisForm";

export default function AnalyzePage() {
  const navigate = useNavigate();
  const toast = useToast();
  const [loading, setLoading] = useState(false);

  async function handleSubmit(payload) {
    setLoading(true);
    try {
      const isCompare = !!payload.second_url;
      const { analysis } = isCompare
        ? await analysisAPI.compare(payload)
        : await analysisAPI.analyze(payload);
      navigate(`/result/${analysis.id}`);
    } catch (err) {
      const msg = err instanceof ApiError && err.errors ? Object.values(err.errors)[0] : err.message;
      toast(msg || "Product analysis failed. Please try again.", "error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container section-tight" style={{ maxWidth: 1000 }}>
      <button className="btn btn-ghost btn-sm" onClick={() => navigate("/dashboard")}>
        <ArrowLeft size={15} /> Home
      </button>

      <div className="section-head" style={{ marginTop: 25, marginBottom: 25 }}>
        <h2>Analyze Product</h2>
        <p>Paste a product URL, tell us what matters most to you, and optionally add a second product to compare.</p>
      </div>

      <Card>
        <AnalysisForm onSubmit={handleSubmit} loading={loading} />
      </Card>
    </div>
  );
}
