import { useNavigate } from "react-router-dom";
import Button from "../components/Button";

export default function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <div className="notfound-wrap">
      <div>
        <div className="notfound-code">404</div>
        <h2 style={{ marginTop: 8, marginBottom: 10 }}>Page not found</h2>
        <p className="text-muted" style={{ marginBottom: 22 }}>The page you're looking for doesn't exist or has moved.</p>
        <Button variant="primary" onClick={() => navigate("/")}>Back to Home</Button>
      </div>
    </div>
  );
}
