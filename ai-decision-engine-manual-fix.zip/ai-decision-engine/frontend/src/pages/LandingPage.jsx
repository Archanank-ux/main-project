import { useNavigate } from "react-router-dom";
import {
  Sparkles, Link as LinkIcon, ShieldCheck, LineChart, BrainCircuit, Boxes,
  Layers, Lock, ArrowRight, CheckCircle2,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import AnalysisForm from "../components/AnalysisForm";
import Button from "../components/Button";
import Footer from "../components/Footer";

export default function LandingPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const toast = useToast();

  function handleAnalyzeAttempt() {
    if (!user) {
      toast("Please log in to continue.", "error");
      navigate("/login");
      return;
    }
    navigate("/analyze");
  }

  return (
    <div className="page">
      <section className="hero">
        <div className="hero-inner">
          <div>
            <span className="hero-eyebrow"><Sparkles size={14} /> AI-POWERED DECISION SUPPORT</span>
            <h1>Make Smarter Decisions with AI</h1>
            <p className="hero-sub">
              Analyze product information intelligently and turn complex product data into
              clear, actionable insights.
            </p>
            <div className="hero-actions">
              <Button variant="primary" size="lg" onClick={handleAnalyzeAttempt}>
                Start Analysis <ArrowRight size={17} />
              </Button>
              <Button variant="outline" size="lg" onClick={handleAnalyzeAttempt}>
                Compare Two Products
              </Button>
              <Button
                variant="ghost"
                size="lg"
                onClick={() => document.getElementById("how-it-works")?.scrollIntoView({ behavior: "smooth" })}
              >
                How It Works
              </Button>
            </div>
          </div>
          <div className="hero-visual">
            {[
              [LinkIcon, "Submit Product URL", "Paste any product link to begin"],
              [Layers, "Structured Data", "Details are validated and organized"],
              [BrainCircuit, "AI Analysis", "Signals are processed for a decision"],
            ].map(([Ic, title, sub]) => (
              <div className="orbit-card" key={title}>
                <div className="orbit-icon"><Ic size={17} /></div>
                <div>
                  <div className="orbit-title">{title}</div>
                  <div className="orbit-sub">{sub}</div>
                </div>
              </div>
            ))}
            <div className="orbit-card final">
              <div className="orbit-icon"><CheckCircle2 size={17} color="#fff" /></div>
              <div>
                <div className="orbit-title">Decision Insights</div>
                <div className="orbit-sub">Clear, actionable recommendation</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="container">
        <div className="analysis-card" id="analyze">
          <div className="analysis-card-head">
            <Sparkles size={20} color="var(--accent)" />
            <h3>Analyze a Product</h3>
          </div>
          <AnalysisForm
            onSubmit={handleAnalyzeAttempt}
            loading={false}
          />
        </div>
      </div>

      <section className="section container" id="features">
        <div className="section-head">
          <h2>Everything you need to decide with confidence</h2>
          <p>A focused toolkit for turning raw product data into a clear verdict.</p>
        </div>
        <div className="feature-grid">
          {[
            [BrainCircuit, "AI-Powered Analysis", "Structured signals are processed to support a clear recommendation."],
            [Boxes, "Smart Decision Support", "Get a decision, a confidence level, and the reasoning behind it."],
            [LineChart, "Product Insights", "Understand what stands out — and what doesn't — about a product."],
            [ShieldCheck, "Data-Driven Results", "Every analysis is stored and tied only to your own account."],
          ].map(([Ic, title, desc]) => (
            <div className="feature-card" key={title}>
              <div className="feature-icon"><Ic size={19} /></div>
              <h4>{title}</h4>
              <p>{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section container" id="decision-explainer">
        <div className="section-head">
          <h2>What BUY, WAIT and DO NOT BUY actually mean</h2>
          <p>Every recommendation comes from the trained model's own prediction, never a fabricated guess.</p>
        </div>
        <div className="feature-grid">
          <div className="feature-card">
            <h4 style={{ color: "#16a34a" }}>BUY</h4>
            <p>The model found strong, trustworthy evidence supporting this product.</p>
          </div>
          <div className="feature-card">
            <h4 style={{ color: "#d97706" }}>WAIT</h4>
            <p>The evidence is mixed, or your stated priority found a real concern worth weighing first.</p>
          </div>
          <div className="feature-card">
            <h4 style={{ color: "#dc2626" }}>DO NOT BUY</h4>
            <p>The model found meaningful warning signs in the product's own data.</p>
          </div>
          <div className="feature-card">
            <h4 style={{ color: "#64748b" }}>INSUFFICIENT DATA</h4>
            <p>There wasn't enough real product data to support any recommendation — we never invent one.</p>
          </div>
        </div>
      </section>

      <section className="section container" id="how-it-works">
        <div className="section-head">
          <h2>How it works</h2>
        </div>
        <div className="steps-grid">
          {[
            ["01", "Enter Product URL", "Paste the link to the product you want analyzed."],
            ["02", "Tell Us Your Priority", "Pick what matters most — quality, price, or durability — and how long you plan to use it."],
            ["03", "AI Analyzes the Information", "The engine processes the signals you've provided."],
            ["04", "Get Decision Insights", "Review a clear decision, confidence, and recommendation."],
          ].map(([n, title, desc]) => (
            <div className="step-card" key={n}>
              <div className="step-num">{n}</div>
              <h4>{title}</h4>
              <p>{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section container">
        <div className="trust-band">
          <h2 style={{ fontSize: 26 }}>Built on solid foundations</h2>
          <p style={{ color: "var(--text-on-navy-muted)", marginTop: 8 }}>The engineering behind every analysis.</p>
          <div className="trust-grid">
            {[
              [BrainCircuit, "Machine Learning"],
              [LineChart, "Data Analysis"],
              [Boxes, "AI Decision Support"],
              [Lock, "Secure Authentication"],
            ].map(([Ic, label]) => (
              <div className="trust-item" key={label}>
                <div className="trust-item-icon"><Ic size={18} color="#fff" /></div>
                <span>{label}</span>
              </div>
            ))}
          </div>
          <p className="trust-caveat">
            Results are decision-support signals, not guarantees — always use your own judgment.
          </p>
        </div>
      </section>

      <section className="section container">
        <div className="cta-band">
          <h2>Ready to make smarter buying calls?</h2>
          <p>Create a free account and run your first analysis in minutes.</p>
          <Button variant="dark" size="lg" onClick={() => navigate(user ? "/analyze" : "/register")}>
            {user ? "Analyze a Product" : "Create Free Account"}
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
}
