import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { AlertCircle } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import Input from "../components/Input";
import PasswordInput from "../components/PasswordInput";
import Button from "../components/Button";

export default function LoginPage() {
  const { login } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [banner, setBanner] = useState("");
  const [loading, setLoading] = useState(false);

  function validate() {
    const errs = {};
    if (!email.trim()) errs.email = "Email is required.";
    if (!password) errs.password = "Password is required.";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setBanner("");
    if (!validate()) return;
    setLoading(true);
    try {
      await login(email.trim(), password);
      toast("Welcome back!", "success");
      navigate(location.state?.from || "/dashboard");
    } catch (err) {
      setBanner(err.message || "Invalid email or password.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-split-wrap">
      <div className="auth-brand-half">
        <div className="brand-mark-large">AI</div>
        <div className="auth-brand-title">AI Product Decision Engine</div>
        <p>Smarter Choices. Better Purchases.</p>
      </div>
      <div className="auth-form-half">
        <div className="auth-card auth-card-split">
          <div className="auth-card-head">
            <h2>Welcome back</h2>
            <p className="text-muted">Sign in to continue to your dashboard.</p>
          </div>
          <div className="auth-panel">
          {banner && (
            <div className="form-error-banner">
              <AlertCircle size={16} /> {banner}
            </div>
          )}
          <form onSubmit={handleSubmit} noValidate>
            <Input label="Email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} placeholder="you@example.com" />
            <PasswordInput label="Password" required value={password} onChange={(e) => setPassword(e.target.value)} error={errors.password} placeholder="••••••••" />
            <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16, marginTop: -8 }}>
              <button type="button" className="link-btn" style={{ fontSize: 13 }} onClick={() => toast("Password reset isn't wired up yet — contact support.", "info")}>
                Forgot password?
              </button>
            </div>
            <Button type="submit" variant="primary" size="lg" className="btn-block" loading={loading}>
              Sign In
            </Button>
          </form>
          <div className="auth-footer-link">
            New here? <button className="link-btn" onClick={() => navigate("/register")}>Create an account</button>
          </div>
          </div>
        </div>
      </div>
    </div>
  );
}
