import { useAuth } from "../context/AuthContext";
import Card from "../components/Card";

export default function ProfilePage() {
  const { user } = useAuth();
  if (!user) return null;
  return (
    <div className="container section-tight" style={{ maxWidth: 560 }}>
      <h2 style={{ marginBottom: 20 }}>Your Profile</h2>
      <Card>
        <div className="detail-row"><span className="label">Full Name</span><span className="value">{user.name}</span></div>
        <div className="detail-row"><span className="label">Email</span><span className="value">{user.email}</span></div>
        <div className="detail-row"><span className="label">Member since</span><span className="value">{new Date(user.created_at).toLocaleDateString()}</span></div>
      </Card>
    </div>
  );
}
