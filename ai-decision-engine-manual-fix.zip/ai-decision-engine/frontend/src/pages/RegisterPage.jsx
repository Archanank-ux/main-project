import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AlertCircle, Check } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import Input from "../components/Input";
import PasswordInput from "../components/PasswordInput";
import Button from "../components/Button";
import { ApiError } from "../services/api";

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

function passwordChecks(pw) {
  return [
    { met: pw.length >= 8, label: "At least 8 characters" },
    { met: /[A-Z]/.test(pw), label: "One uppercase letter" },
    { met: /[a-z]/.test(pw), label: "One lowercase letter" },
    { met: /\d/.test(pw), label: "One number" },
    { met: /[^A-Za-z0-9]/.test(pw), label: "One special character (recommended)" },
  ];
}

export default function RegisterPage() {
  const { register } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const [errors, setErrors] = useState({});
  const [banner, setBanner] = useState("");
  const [loading, setLoading] = useState(false);

  const checks = passwordChecks(form.password);
  const requiredChecksMet = checks.slice(0, 4).every((c) => c.met);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
    if (errors[field]) setErrors((e) => ({ ...e, [field]: null }));
  }

  function validate() {
    const errs = {};
    if (form.name.trim().length < 2) errs.name = "Full name must be at least 2 characters.";
    if (!EMAIL_RE.test(form.email.trim())) errs.email = "Please enter a valid email address.";
    if (!requiredChecksMet) errs.password = "Please meet all password requirements.";
    if (form.password !== form.confirmPassword) errs.confirmPassword = "Passwords do not match.";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setBanner("");
    if (!validate()) return;
    setLoading(true);
    try {
      await register({
        name: form.name.trim(),
        email: form.email.trim(),
        password: form.password,
        confirm_password: form.confirmPassword,
      });
      toast("Account created — please sign in.", "success");
      navigate("/login");
    } catch (err) {
      if (err instanceof ApiError && err.errors) {
        setErrors({
          name: err.errors.name,
          email: err.errors.email,
          password: err.errors.password,
          confirmPassword: err.errors.confirm_password,
        });
      } else {
        setBanner(err.message || "Something went wrong. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-split-wrap">
      <div className="auth-brand-half">
        <div className="brand-mark-large">AI</div>
        <div className="auth-brand-title">AI Product Decision Engine</div>
        <p>Smarter Choices. Better Purchases.</p>
      </div>
      <div className="auth-form-half">
        <div className="auth-card auth-card-split">
          <div className="auth-card-head">
            <h2>Create your account</h2>
            <p className="text-muted">Start getting AI-powered decision insights.</p>
          </div>
          <div className="auth-panel">
            {banner && (
              <div className="form-error-banner">
                <AlertCircle size={16} /> {banner}
              </div>
            )}
            <form onSubmit={handleSubmit} noValidate>
              <Input label="Full Name" required value={form.name} onChange={(e) => update("name", e.target.value)} error={errors.name} placeholder="Jane Doe" />
              <Input label="Email" type="email" required value={form.email} onChange={(e) => update("email", e.target.value)} error={errors.email} placeholder="you@example.com" />
              <PasswordInput label="Password" required value={form.password} onChange={(e) => update("password", e.target.value)} error={errors.password} placeholder="••••••••" />
              {form.password && (
                <div className="password-requirements">
                  {checks.map((c) => (
                    <div className={`pw-req ${c.met ? "met" : ""}`} key={c.label}>
                      <span className="pw-req-dot">{c.met && <Check size={10} />}</span>
                      {c.label}
                    </div>
                  ))}
                </div>
              )}
              <PasswordInput label="Confirm Password" required value={form.confirmPassword} onChange={(e) => update("confirmPassword", e.target.value)} error={errors.confirmPassword} placeholder="••••••••" />
              <Button type="submit" variant="primary" size="lg" className="btn-block" loading={loading} style={{ marginTop: 6 }}>
                Create Account
              </Button>
            </form>
            <div className="auth-footer-link">
              Already have an account? <button className="link-btn" onClick={() => navigate("/login")}>Sign in</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
