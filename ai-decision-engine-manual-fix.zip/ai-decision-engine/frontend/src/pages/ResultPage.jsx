import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { AlertTriangle } from "lucide-react";
import { analysisAPI } from "../services/api";
import AnalysisResult from "../components/AnalysisResult";
import LoadingSpinner from "../components/LoadingSpinner";
import EmptyState from "../components/EmptyState";
import Button from "../components/Button";

export default function ResultPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [analysis, setAnalysis] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    setAnalysis(null);
    setError("");
    analysisAPI
      .getOne(id)
      .then((d) => setAnalysis(d.analysis))
      .catch((e) => setError(e.message || "Could not load this analysis."));
  }, [id]);

  if (error) {
    return (
      <div className="container section-tight">
        <EmptyState
          icon={AlertTriangle}
          title="Couldn't load this analysis"
          message={error}
          action={<Button variant="primary" onClick={() => navigate("/dashboard")}>Back to Dashboard</Button>}
        />
      </div>
    );
  }

  if (!analysis) return <LoadingSpinner label="Loading result…" />;

  return (
    <div className="container section-tight">
      <button className="btn btn-ghost btn-sm" style={{ marginBottom: 16 }} onClick={() => navigate("/dashboard")}>
        ← Back to Dashboard
      </button>
      <AnalysisResult analysis={analysis} />
    </div>
  );
}
