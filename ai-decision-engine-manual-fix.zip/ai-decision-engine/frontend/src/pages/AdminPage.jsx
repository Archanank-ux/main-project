import { useEffect, useState } from "react";
import { Shield, Users, BarChart3, FileText, LogIn, RefreshCw } from "lucide-react";
import Button from "../components/Button";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const ADMIN_TOKEN_KEY = "ai_decision_engine_admin_token";

function adminRequest(path, options = {}) {
  const token = localStorage.getItem(ADMIN_TOKEN_KEY);
  return fetch(`${API_URL}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  }).then(async (res) => {
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.message || "Admin request failed.");
    return data;
  });
}

export default function AdminPage() {
  const [loggedIn, setLoggedIn] = useState(!!localStorage.getItem(ADMIN_TOKEN_KEY));
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [data, setData] = useState(null);
  const [logs, setLogs] = useState("");
  const [error, setError] = useState("");

  async function load() {
    try {
      const result = await adminRequest("/admin/overview");
      setData(result);
      const logResult = await adminRequest("/admin/logs");
      setLogs(logResult.content || "");
    } catch (e) {
      setError(e.message);
      setLoggedIn(false);
      localStorage.removeItem(ADMIN_TOKEN_KEY);
    }
  }

  useEffect(() => { if (loggedIn) load(); }, [loggedIn]);

  async function login(e) {
    e.preventDefault();
    setError("");
    try {
      const res = await fetch(`${API_URL}/admin/login`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.message || "Invalid admin credentials.");
      localStorage.setItem(ADMIN_TOKEN_KEY, result.access_token);
      setLoggedIn(true);
    } catch (e) { setError(e.message); }
  }

  if (!loggedIn) return (
    <div className="container section-tight admin-page">
      <div className="card admin-login-card">
        <div className="admin-icon"><Shield size={24} /></div>
        <h2>Admin Login</h2>
        <p className="text-muted">Sign in to view users, analysis activity, and the application log.</p>
        {error && <div className="admin-error">{error}</div>}
        <form onSubmit={login}>
          <div className="field"><label>Admin Email</label><input value={email} onChange={e => setEmail(e.target.value)} type="email" required /></div>
          <div className="field"><label>Password</label><input value={password} onChange={e => setPassword(e.target.value)} type="password" required /></div>
          <Button type="submit" variant="primary" size="lg" className="btn-block"><LogIn size={17} /> Sign in</Button>
        </form>
      </div>
    </div>
  );

  return (
    <div className="container section-tight admin-page">
      <div className="admin-head">
        <div><div className="eyebrow"><Shield size={14} /> Administration</div><h2>Admin Dashboard</h2><p className="text-muted">Monitor registered users and product analysis activity.</p></div>
        <Button variant="outline" onClick={load}><RefreshCw size={15} /> Refresh</Button>
      </div>
      {error && <div className="admin-error">{error}</div>}
      {data && <>
        <div className="admin-stats">
          <div className="stat-card"><Users size={19}/><span>Users</span><strong>{data.stats.users}</strong></div>
          <div className="stat-card"><BarChart3 size={19}/><span>Analyses</span><strong>{data.stats.analyses}</strong></div>
          <div className="stat-card"><FileText size={19}/><span>Completed</span><strong>{data.stats.completed}</strong></div>
        </div>
        <div className="admin-grid">
          <div className="card admin-table-card"><h3>Registered Users</h3><div className="admin-table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Analyses</th><th>Joined</th></tr></thead><tbody>{data.users.map(u => <tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u.analysis_count}</td><td>{u.created_at ? new Date(u.created_at).toLocaleString() : "—"}</td></tr>)}</tbody></table></div></div>
          <div className="card admin-table-card"><h3>Recent Analyses</h3><div className="admin-table-wrap"><table><thead><tr><th>User</th><th>Product</th><th>Method</th><th>Decision</th></tr></thead><tbody>{data.analyses.map(a => <tr key={a.id}><td>{a.user_name}</td><td>{a.product_name || "Unnamed"}</td><td>{a.method}</td><td><span className={`decision-pill ${String(a.decision).toLowerCase()}`}>{a.decision}</span></td></tr>)}</tbody></table></div></div>
        </div>
        <div className="card admin-log-card"><h3><FileText size={17}/> Application Log</h3><pre>{logs}</pre></div>
      </>}
    </div>
  );
}
