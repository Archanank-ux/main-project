from flask_sqlalchemy import SQLAlchemy

# Single shared SQLAlchemy instance, imported by every model and by app.py.
db = SQLAlchemy()
