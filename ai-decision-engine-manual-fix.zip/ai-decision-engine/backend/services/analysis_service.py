"""
Analysis orchestration: collect product data, run the trained models, persist result.
"""
from database import db
from models.analysis import Analysis
from services.product_analysis_service import collect_manual, collect_selenium, analyze_product, personalize
from services.review_dataset_service import enrich_product


def _run_single(method: str, url: str, priority, duration) -> dict:
    """Shared single-product pipeline, used by both single-URL analysis and
    each side of a two-product comparison, so both paths run identical logic."""
    if method == "selenium":
        product = collect_selenium(url)
    else:
        product = collect_manual(url)

    # If the product exists in the bundled cleaned review dataset, use those
    # reviews as the evidence base for trust/pros/cons as well.
    product = enrich_product(product)

    result = analyze_product({**product, "analysis_method": method})
    result = personalize(result, priority, duration)
    return result


def run_analysis(user_id: int, payload: dict) -> Analysis:
    method = (payload.get("analysis_method") or "manual").lower()
    url = (payload.get("url") or payload.get("product_url") or "").strip()
    second_url = (payload.get("second_url") or "").strip()
    priority = payload.get("priority")
    duration = payload.get("duration")

    if second_url:
        return _run_compare(user_id, method, url, second_url, priority, duration, payload)

    result = _run_single(method, url, priority, duration)

    analysis = Analysis(
        user_id=user_id,
        product_url=url,
        product_name=result["product"]["name"] or payload.get("product_name"),
        category=result["product"].get("category") or payload.get("category"),
        description=result["product"].get("description") or payload.get("description"),
        price=_safe_float(result["product"].get("price")),
        additional_details=payload.get("additional_details"),
        status="completed" if result.get("success") else "failed",
    )
    analysis.result = result
    db.session.add(analysis)
    db.session.commit()
    return analysis


def _winner_for_priority(result_a: dict, result_b: dict, priority: str):
    """Only name a winner when the real evidence for the chosen priority
    actually distinguishes the two products. Otherwise say so honestly."""
    priority = (priority or "").strip().lower()
    a_review = result_a.get("review_analysis", {}) or {}
    b_review = result_b.get("review_analysis", {}) or {}

    def metric(review, product):
        if priority == "quality":
            return review.get("review_trust_score")
        if priority == "price":
            p = product.get("price")
            return -float(p) if p is not None else None
        if priority == "durability":
            return None  # no numeric durability metric exists; decided qualitatively below
        return None

    a_val = metric(a_review, result_a.get("product", {}))
    b_val = metric(b_review, result_b.get("product", {}))

    if priority == "durability":
        a_warn = any("build" in c.lower() or "durab" in c.lower() or "cheap" in c.lower() for c in (result_a.get("cons") or []))
        b_warn = any("build" in c.lower() or "durab" in c.lower() or "cheap" in c.lower() for c in (result_b.get("cons") or []))
        if a_warn and not b_warn:
            return "product_b", "Product B has no reported durability concerns while Product A does."
        if b_warn and not a_warn:
            return "product_a", "Product A has no reported durability concerns while Product B does."
        return None, "No sufficiently supported winner for durability: no clear durability-related evidence differs between the two products."

    if a_val is None or b_val is None or a_val == b_val:
        return None, f"No sufficiently supported winner for {priority or 'this priority'}: not enough comparable evidence was found for both products."

    if a_val > b_val:
        return "product_a", f"Product A has the stronger {priority} evidence ({a_val:.1f} vs {b_val:.1f})."
    return "product_b", f"Product B has the stronger {priority} evidence ({b_val:.1f} vs {a_val:.1f})."


def _run_compare(user_id, method, url, second_url, priority, duration, payload) -> Analysis:
    result_a = _run_single(method, url, priority, duration)
    result_b = _run_single(method, second_url, priority, duration)

    winner, winner_reason = _winner_for_priority(result_a, result_b, priority)
    comparison = {
        "product_a": result_a,
        "product_b": result_b,
        "summary": {
            "priority": priority,
            "winner": winner,
            "winner_reason": winner_reason,
        },
    }

    combined = {
        "success": bool(result_a.get("success") and result_b.get("success")),
        "is_comparison": True,
        "analysis_method": method,
        "comparison": comparison,
        # Keep top-level product/decision pointing at product A so any legacy
        # code that reads result.product / result.decision still gets a
        # sensible single value, without hiding product B's own result.
        "decision": result_a.get("decision"),
        "decision_raw": result_a.get("decision_raw"),
        "product": result_a.get("product"),
        "review_analysis": result_a.get("review_analysis"),
        "pros": result_a.get("pros"),
        "cons": result_a.get("cons"),
        "explain": result_a.get("explain"),
        "personalization": result_a.get("personalization"),
    }

    analysis = Analysis(
        user_id=user_id,
        product_url=url,
        product_name=result_a["product"]["name"] or payload.get("product_name"),
        category=result_a["product"].get("category") or payload.get("category"),
        description=f"Comparison vs: {second_url}",
        price=_safe_float(result_a["product"].get("price")),
        additional_details=payload.get("additional_details"),
        status="completed" if combined["success"] else "failed",
    )
    analysis.result = combined
    db.session.add(analysis)
    db.session.commit()
    return analysis


def compare_products(user_id: int, payload: dict) -> Analysis:
    """Explicit entry point for the /compare endpoint."""
    method = (payload.get("analysis_method") or "manual").lower()
    url = (payload.get("url") or payload.get("product_url") or "").strip()
    second_url = (payload.get("second_url") or "").strip()
    priority = payload.get("priority")
    duration = payload.get("duration")
    return _run_compare(user_id, method, url, second_url, priority, duration, payload)


def get_user_history(user_id: int, limit: int = 50):
    return Analysis.query.filter_by(user_id=user_id).order_by(Analysis.created_at.desc()).limit(limit).all()


def get_user_analysis(user_id: int, analysis_id: int):
    return Analysis.query.filter_by(id=analysis_id, user_id=user_id).first()


def delete_user_analysis(user_id: int, analysis_id: int) -> bool:
    analysis = Analysis.query.filter_by(id=analysis_id, user_id=user_id).first()
    if not analysis:
        return False
    db.session.delete(analysis)
    db.session.commit()
    return True


def get_user_stats(user_id: int) -> dict:
    total = Analysis.query.filter_by(user_id=user_id).count()
    successful = Analysis.query.filter_by(user_id=user_id, status="completed").count()
    recent = Analysis.query.filter_by(user_id=user_id).order_by(Analysis.created_at.desc()).limit(5).all()
    return {
        "total_analyses": total,
        "successful_analyses": successful,
        "recent_analyses": [a.to_dict(include_result=False) for a in recent],
    }


def _safe_float(value):
    try:
        return float(value) if value not in (None, "") else None
    except (TypeError, ValueError):
        return None
