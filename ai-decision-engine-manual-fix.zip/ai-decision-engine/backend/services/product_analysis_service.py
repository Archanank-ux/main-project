"""
Product collection and feature engineering.

Manual mode:
  Uses a normal HTTP request + HTML parsing. This is the lightweight path.

Selenium mode:
  Opens the URL in a real browser and parses the rendered HTML.

Both modes return the same normalized product structure, so the ML
pipeline stays identical.
"""

import json
import re
import statistics
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

from ml.model_service import ml_model_service
from ml.selenium_model_service import selenium_model_service
from utils.platform import validate_platform_url, detect_platform


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/154.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-IN,en;q=0.9",
}


def _num(value):
    if value is None:
        return None
    s = str(value).replace(",", "").replace("₹", "").replace("$", "").replace("Rs.", "")
    m = re.search(r"\d+(?:\.\d+)?", s)
    return float(m.group()) if m else None


def _rating(value):
    x = _num(value)
    if x is None:
        return None
    return min(5.0, max(0.0, x))


def _text(el):
    return el.get_text(" ", strip=True) if el else ""


def _meta(soup, *names):
    for name in names:
        tag = soup.find("meta", attrs={"property": name}) or soup.find("meta", attrs={"name": name})
        if tag and tag.get("content"):
            return tag["content"].strip()
    return ""


def _jsonld_objects(soup):
    objects = []
    for tag in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(tag.string or tag.get_text())
            if isinstance(data, list):
                objects.extend(data)
            elif isinstance(data, dict) and "@graph" in data:
                objects.extend(data["@graph"])
            else:
                objects.append(data)
        except Exception:
            continue
    return objects


def _from_jsonld(soup):
    product = {}
    reviews = []
    for obj in _jsonld_objects(soup):
        if not isinstance(obj, dict):
            continue
        typ = obj.get("@type")
        types = typ if isinstance(typ, list) else [typ]
        if "Product" in types:
            product["name"] = obj.get("name") or product.get("name")
            product["description"] = obj.get("description") or product.get("description")
            product["image"] = obj.get("image") or product.get("image")
            offers = obj.get("offers")
            if isinstance(offers, list):
                offers = offers[0] if offers else {}
            if isinstance(offers, dict):
                product["price"] = _num(offers.get("price"))
            agg = obj.get("aggregateRating") or {}
            if isinstance(agg, dict):
                product["rating"] = _rating(agg.get("ratingValue"))
                product["review_count"] = int(_num(agg.get("reviewCount")) or 0)
            raw_reviews = obj.get("review") or []
            if isinstance(raw_reviews, dict):
                raw_reviews = [raw_reviews]
            for r in raw_reviews[:100]:
                if not isinstance(r, dict):
                    continue
                author = r.get("author")
                if isinstance(author, dict):
                    author = author.get("name")
                rating = r.get("reviewRating") or {}
                reviews.append({
                    "text": str(r.get("reviewBody") or ""),
                    "rating": _rating(rating.get("ratingValue")),
                    "helpful_votes": 0,
                    "photos": 0,
                    "author": author or "",
                })
    product["reviews"] = reviews
    return product


def _generic_reviews(soup):
    reviews = []
    selectors = [
        '[data-hook="review"]',
        '[data-hook="review-body"]',
        '[class*="review"]',
        '[class*="Review"]',
    ]
    seen = set()
    for sel in selectors:
        for node in soup.select(sel):
            text = _text(node)
            if len(text) < 15 or text in seen:
                continue
            seen.add(text)
            rating = None
            rnode = node.select_one('[class*="rating"], [aria-label*="out of 5"], [aria-label*="stars"]')
            if rnode:
                rating = _rating(rnode.get("aria-label") or _text(rnode))
            if rating is None:
                m = re.search(r"([1-5](?:\.\d)?)\s*(?:out of 5|/5|stars?)", text, re.I)
                rating = _rating(m.group(1)) if m else None
            reviews.append({"text": text[:2000], "rating": rating, "helpful_votes": 0, "photos": 0, "author": ""})
            if len(reviews) >= 100:
                return reviews
    return reviews


def parse_product_html(html, url):
    soup = BeautifulSoup(html, "html.parser")
    data = _from_jsonld(soup)

    data["name"] = data.get("name") or _meta(soup, "og:title", "twitter:title") or _text(soup.find("h1"))
    data["description"] = data.get("description") or _meta(soup, "og:description", "description")
    data["image"] = data.get("image") or _meta(soup, "og:image")

    if not data.get("price"):
        price_selectors = [
            '[itemprop="price"]', '.a-price-whole', '[class*="price"]',
            '[class*="Price"]', '[data-price]'
        ]
        for sel in price_selectors:
            el = soup.select_one(sel)
            if el:
                data["price"] = _num(el.get("content") or el.get("data-price") or _text(el))
                if data["price"]:
                    break

    if not data.get("rating"):
        for sel in ['[itemprop="ratingValue"]', '[class*="rating"]', '[class*="Rating"]']:
            el = soup.select_one(sel)
            if el:
                data["rating"] = _rating(el.get("content") or el.get("aria-label") or _text(el))
                if data["rating"]:
                    break

    if not data.get("review_count"):
        for sel in ['[itemprop="reviewCount"]', '[class*="review-count"]', '[class*="reviewCount"]']:
            el = soup.select_one(sel)
            if el:
                data["review_count"] = int(_num(el.get("content") or _text(el)) or 0)
                if data["review_count"]:
                    break

    if not data.get("reviews"):
        data["reviews"] = _generic_reviews(soup)

    data["url"] = url
    data["category"] = _category_from_url(url, soup)
    return data


def _category_from_url(url, soup):
    for sel in ['[itemprop="category"]', 'nav[aria-label*="breadcrumb"]', '[class*="breadcrumb"]']:
        el = soup.select_one(sel)
        if el:
            parts = [x.strip() for x in _text(el).split(">") if x.strip()]
            if parts:
                return parts[-2] if len(parts) > 1 else parts[0]
    path = [p for p in urlparse(url).path.split("/") if p]
    return path[-2].replace("-", " ").title() if len(path) >= 2 else ""



def resolve_product_url(product_name):
    """Resolve a product name to an Amazon product URL when needed."""
    from urllib.parse import quote_plus
    if not product_name.strip():
        raise ValueError("Please enter a product URL.")
    query = quote_plus(f"site:amazon.in {product_name} product")
    search_url = f"https://html.duckduckgo.com/html/?q={query}"
    response = requests.get(search_url, headers=HEADERS, timeout=15)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    for a in soup.select("a.result__a"):
        href = a.get("href") or ""
        if href.startswith("//"):
            href = "https:" + href
        if "amazon.in" in href.lower() and "/dp/" in href.lower():
            return href
    raise ValueError("Could not find a matching product page. Please enter the product URL.")


def collect_manual(url):
    """Collect in Manual mode, with a browser-render fallback for JS/block pages.

    Many shopping sites (including Amazon) return incomplete HTML to ordinary
    HTTP clients. Manual mode therefore tries the lightweight requests parser
    first, then uses the same rendered-page collector as Selenium mode only
    when the HTTP result is clearly missing essential product fields. The
    selected analysis model remains the Manual/12-feature model.
    """
    platform = validate_platform_url(url)
    manual_data = {}
    manual_error = None

    try:
        response = requests.get(url, headers=HEADERS, timeout=20)
        response.raise_for_status()
        manual_data = parse_product_html(response.text, url)
        manual_data["platform"] = platform
    except requests.RequestException as exc:
        manual_error = exc

    # A product name is essential. Price and rating are also commonly omitted
    # when the retailer serves a JavaScript shell or an anti-bot response.
    missing_core_data = (
        not (manual_data.get("name") or "").strip()
        or (manual_data.get("price") is None and manual_data.get("rating") is None)
    )

    if manual_error is None and not missing_core_data:
        return manual_data

    try:
        rendered_data = collect_selenium(url)
        # Prefer the rendered page values, but retain useful HTTP values if a
        # field is absent from the browser-rendered markup.
        merged = dict(manual_data)
        for key, value in rendered_data.items():
            if value not in (None, "", []):
                merged[key] = value
        merged["platform"] = platform
        return merged
    except Exception as browser_error:
        if manual_data and manual_data.get("name"):
            # Keep any real data already collected instead of discarding it.
            return manual_data
        reason = str(manual_error or browser_error)
        raise ValueError(
            "Manual collection could not retrieve product details. "
            f"The browser fallback also failed: {reason}"
        ) from browser_error


def collect_selenium(url):
    platform = validate_platform_url(url)
    from selenium import webdriver
    from selenium.webdriver.edge.options import Options as EdgeOptions
    from selenium.webdriver.chrome.options import Options as ChromeOptions

    try:
        options = EdgeOptions()
        options.add_argument("--headless=new")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1440,1000")
        options.add_argument(f"user-agent={HEADERS['User-Agent']}")
        driver = webdriver.Edge(options=options)
    except Exception:
        options = ChromeOptions()
        options.add_argument("--headless=new")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1440,1000")
        options.add_argument(f"user-agent={HEADERS['User-Agent']}")
        driver = webdriver.Chrome(options=options)

    try:
        driver.get(url)
        html = driver.page_source
    finally:
        driver.quit()
    data = parse_product_html(html, url)
    data["platform"] = platform
    return data


def _aspect_pros_cons(reviews, fake_probs=None, price=None, budget=None):
    """Create concise product-level pros/cons from review evidence.

    We never display the raw customer review as a pro/con.  Instead, review
    text is scanned for an aspect + sentiment and converted into a short,
    reusable statement.  This also works with the bundled review dataset.
    """
    aspects = [
        {
            "name": "camera", "positive": ["excellent camera", "great camera", "good camera", "camera quality", "camera is good", "camera is excellent"],
            "negative": ["bad camera", "poor camera", "camera could be better", "camera quality is poor", "camera quality could be better"],
            "pro": "Excellent camera quality", "con": "Camera quality could be better",
        },
        {
            "name": "display", "positive": ["bright display", "clear display", "excellent display", "good display", "beautiful display", "screen is bright", "screen is clear"],
            "negative": ["poor display", "bad display", "dim display", "screen is dull", "display could be better"],
            "pro": "Bright and clear display", "con": "Display quality could be better",
        },
        {
            "name": "performance", "positive": ["fast performance", "smooth performance", "great performance", "good performance", "fast and smooth", "runs smoothly", "very fast"],
            "negative": ["slow performance", "lag", "lags", "slow", "stutters", "performance issue"],
            "pro": "Fast and smooth performance", "con": "Performance can be slow at times",
        },
        {
            "name": "battery", "positive": ["good battery", "great battery", "excellent battery", "long battery", "battery life is good", "battery life is excellent"],
            "negative": ["poor battery", "bad battery", "battery drains", "battery drain", "battery life could be better", "short battery"],
            "pro": "Good battery life", "con": "Battery life could be better",
        },
        {
            "name": "build", "positive": ["solid build", "strong build", "good build quality", "excellent build", "sturdy", "premium build"],
            "negative": ["poor build", "bad build", "cheap build", "cheap plastic", "build quality is not good", "build quality could be better"],
            "pro": "Strong build quality", "con": "Build quality could be better",
        },
        {
            "name": "design", "positive": ["premium design", "beautiful design", "good design", "sleek design", "attractive design", "elegant design"],
            "negative": ["bad design", "poor design", "bulky", "too heavy"],
            "pro": "Premium and attractive design", "con": "Design is bulky or inconvenient",
        },
        {
            "name": "charging", "positive": ["fast charging", "quick charging", "charges quickly", "charging is fast"],
            "negative": ["slow charging", "charging is slow", "charger not included", "charger is not included", "without charger", "no charger", "no charging adapter"],
            "pro": "Fast charging", "con": "No charger included",
        },
        {
            "name": "sound", "positive": ["good sound", "great sound", "excellent sound", "clear sound", "good speaker", "loud speaker"],
            "negative": ["poor sound", "bad sound", "speaker is weak", "low sound"],
            "pro": "Good sound quality", "con": "Sound quality could be better",
        },
        {
            "name": "cooling", "positive": ["good cooling", "excellent cooling", "great cooling", "cooling is good", "cools well", "airflow is good", "air flow is good"],
            "negative": ["poor cooling", "bad cooling", "cooling is not good", "cooling is less", "not cooling", "airflow is poor", "air flow is poor"],
            "pro": "Excellent cooling performance", "con": "Cooling performance could be better",
        },
        {
            "name": "price", "positive": ["value for money", "worth the money", "worth every penny", "affordable", "good price", "reasonable price"],
            "negative": ["expensive", "costly", "overpriced", "price is high", "too expensive", "not worth the price", "not worth it"],
            "pro": "Good value for money", "con": "Expensive price",
        },
    ]

    positive_generic = ("excellent", "great", "good", "amazing", "awesome", "satisfied", "worth", "value for money", "best", "perfect", "smooth", "fast")
    negative_generic = ("poor", "bad", "worst", "terrible", "pathetic", "issue", "problem", "not good", "not worth", "waste", "disappoint", "broken", "no ", "without", "expensive", "costly", "overpriced")

    fake_probs = fake_probs or []
    pos_score, neg_score = {}, {}

    for idx, review in enumerate(reviews):
        text = str(review.get("text") or "").strip()
        if not text:
            continue
        # Do not let a likely fake review dominate the feature summary.
        if idx < len(fake_probs) and fake_probs[idx] >= 0.5:
            continue

        low = re.sub(r"\s+", " ", text.lower())
        try:
            rating = float(review.get("rating")) if review.get("rating") is not None else None
        except (TypeError, ValueError):
            rating = None

        for a in aspects:
            pos_hit = any(term in low for term in a["positive"])
            neg_hit = any(term in low for term in a["negative"])

            # Ratings are used only as a tie-breaker; explicit text sentiment wins.
            if pos_hit and not neg_hit:
                pos_score[a["pro"]] = pos_score.get(a["pro"], 0) + 1
            elif neg_hit and not pos_hit:
                neg_score[a["con"]] = neg_score.get(a["con"], 0) + 1
            elif pos_hit and neg_hit:
                # Mixed review: choose based on rating when available.
                if rating is not None and rating >= 4:
                    pos_score[a["pro"]] = pos_score.get(a["pro"], 0) + 1
                elif rating is not None and rating <= 2:
                    neg_score[a["con"]] = neg_score.get(a["con"], 0) + 1

        # Useful fallback for clearly positive/negative reviews that mention an
        # aspect not covered by the small phrase dictionary.
        if rating is not None and rating >= 4:
            for phrase in positive_generic:
                if phrase in low:
                    pos_score["Positive customer feedback"] = pos_score.get("Positive customer feedback", 0) + 0.25
                    break
        if rating is not None and rating <= 2:
            for phrase in negative_generic:
                if phrase in low:
                    neg_score["Some customers reported issues"] = neg_score.get("Some customers reported issues", 0) + 0.25
                    break

    def top_items(scores, limit=5):
        return [phrase for phrase, score in sorted(scores.items(), key=lambda x: (-x[1], x[0]))[:limit]]

    pros = top_items(pos_score)
    cons = top_items(neg_score)

    # Budget context is kept as a personal recommendation signal, not as a
    # review-derived con. This prevents every product over a user's budget from
    # falsely claiming that reviews said it was expensive.
    return pros[:5], cons[:5]

def _analyze_manual(data):
    """Full/deep Manual analysis using the existing 12-feature model."""
    reviews = data.get("reviews") or []
    rated = [r for r in reviews if r.get("rating") is not None]
    ratings = [float(r["rating"]) for r in rated]
    count = int(data.get("review_count") or len(reviews) or 0)

    avg_rating = float(data.get("rating") or (statistics.mean(ratings) if ratings else 0))
    helpful = [float(r.get("helpful_votes") or 0) for r in reviews]
    photos = [float(r.get("photos") or 0) for r in reviews]

    fake_probs = ml_model_service.predict_fake_reviews(reviews) if reviews else []
    fake_pct = (sum(1 for p in fake_probs if p >= 0.5) / len(fake_probs) * 100) if fake_probs else 0.0
    genuine_pct = 100 - fake_pct

    avg_helpful = statistics.mean(helpful) if helpful else 0.0
    avg_photos = statistics.mean(photos) if photos else 0.0
    rating_coverage = min(100.0, len(rated) / max(1, len(reviews)) * 100)
    helpful_score = min(100.0, avg_helpful * 20.0)
    trust = round(0.70 * genuine_pct + 0.20 * rating_coverage + 0.10 * helpful_score, 2)

    rating_pct = {f"rating_{i}_percentage": 0.0 for i in range(1, 6)}
    for i in range(1, 6):
        rating_pct[f"rating_{i}_percentage"] = round(
            sum(1 for r in ratings if int(round(r)) == i) / max(1, len(ratings)) * 100, 2
        )

    features = {
        "review_count": count,
        "average_rating": avg_rating,
        "helpful_votes": sum(helpful),
        "average_helpful_votes": avg_helpful,
        "average_photos": avg_photos,
        "fake_review_percentage": fake_pct,
        "review_trust": trust,
        **rating_pct,
    }
    prediction = ml_model_service.predict_decision(features)
    pros, cons = _aspect_pros_cons(reviews, fake_probs=fake_probs, price=data.get("price"))

    return {
        "success": True,
        "decision": prediction["decision"],
        "confidence": prediction["confidence"],
        "model_status": "live",
        "analysis_method": "manual",
        "product": {
            "name": data.get("name") or "", "url": data.get("url") or "",
            "price": data.get("price"), "rating": avg_rating, "review_count": count,
            "category": data.get("category") or "", "description": data.get("description") or "",
            "image": data.get("image") or "",
        },
        "review_analysis": {
            "review_trust_score": trust,
            "fake_review_percentage": round(fake_pct, 2),
            "genuine_review_percentage": round(genuine_pct, 2),
            "features": features,
        },
        "pros": pros,
        "cons": cons,
    }


def _analyze_selenium(data):
    """Small/fast Selenium analysis using a separate 4-feature model."""
    reviews = data.get("reviews") or []
    rated = [r for r in reviews if r.get("rating") is not None]
    ratings = [float(r["rating"]) for r in rated]
    avg_rating = float(data.get("rating") or (statistics.mean(ratings) if ratings else 0))
    review_count = int(data.get("review_count") or len(reviews) or 0)
    positive_pct = round(
        sum(1 for rating in ratings if rating >= 4.0) / max(1, len(ratings)) * 100,
        2,
    )

    features = {
        "price": float(data.get("price") or 0),
        "rating": avg_rating,
        "rating_count": review_count,
        "positive_review_pct": positive_pct,
    }
    prediction = selenium_model_service.predict(features)
    return {
        "success": True,
        "decision": prediction["decision"],
        "confidence": prediction["confidence"],
        "model_status": "live",
        "analysis_method": "selenium",
        "product": {
            "name": data.get("name") or "", "url": data.get("url") or "",
            "price": data.get("price"), "rating": avg_rating, "review_count": review_count,
            "category": data.get("category") or "", "description": data.get("description") or "",
            "image": data.get("image") or "",
        },
        "review_analysis": {
            "features": features,
            "positive_review_pct": positive_pct,
        },
        "pros": [],
        "cons": [],
    }


def analyze_product(data):
    """Dispatch to the intentionally separate Manual or Selenium pipeline."""
    if (data.get("analysis_method") or "manual").lower() == "selenium":
        return _analyze_selenium(data)
    return _analyze_manual(data)

_VALID_PRIORITIES = {"quality", "price", "durability"}
_VALID_DURATIONS = {"short_term", "long_term"}
_DURABILITY_CON_HINTS = ("build quality could be better", "design is bulky", "cheap", "short battery", "battery life could be better")


def personalize(result, priority=None, duration=None):
    """Add an explainable, documented recommendation layer.

    The original trained-model decision is NEVER mutated — it is preserved
    as `decision_raw`. Priority/duration are user preferences, never model
    features: any adjustment here is a separate, visible, reason-logged
    step layered on top of the real model output. `result["decision"]`
    continues to hold the model's decision unless this function explicitly
    overrides it for a documented reason, in which case `decision_raw`
    shows what the model actually said.
    """
    priority = (priority or "").strip().lower() or None
    duration = (duration or "").strip().lower() or None
    if priority not in _VALID_PRIORITIES:
        priority = None
    if duration not in _VALID_DURATIONS:
        duration = None

    product = result.get("product", {}) or {}
    review = result.get("review_analysis", {}) or {}
    price = product.get("price")
    rating = product.get("rating")
    decision_raw = result.get("decision", "WAIT")
    decision = decision_raw
    reasons = []

    trust_score = review.get("review_trust_score")
    fake_pct = review.get("fake_review_percentage")
    cons = result.get("cons") or []

    # --- Priority: Quality -> weigh review trust / fake-review signal ---
    if priority == "quality" and fake_pct is not None:
        reasons.append(f"Priority is quality, and {fake_pct:.0f}% of reviews look potentially fake.")
        if fake_pct >= 40 and decision == "BUY":
            decision = "WAIT"
            reasons.append("Downgraded from BUY to WAIT because high fake-review share undermines a quality-first decision.")

    # --- Priority: Price -> no model feature exists for price sensitivity;
    # state that honestly rather than fabricating one ---
    if priority == "price":
        if price is not None:
            reasons.append(f"Priority is price. Listed price is ₹{float(price):,.0f}.")
        else:
            reasons.append("Priority is price, but no price was found on the product page.")

    # --- Priority: Durability -> look for real durability-related cons ---
    if priority == "durability":
        durability_hits = [c for c in cons if any(h in c.lower() for h in _DURABILITY_CON_HINTS)]
        if durability_hits:
            reasons.append(f"Priority is durability. Found a durability concern in product evidence: {durability_hits[0]}")
            if decision == "BUY":
                decision = "WAIT"
                reasons.append("Downgraded from BUY to WAIT because a real durability concern was found in the evidence.")
        else:
            reasons.append("Priority is durability. No durability-related concern was found in the available evidence.")

    # --- Duration: long-term use leans on the same trust/durability signals ---
    if duration == "long_term":
        if trust_score is not None and trust_score < 50 and decision in ("BUY", "WAIT"):
            reasons.append(f"Intended for long-term use, and review trust score is low ({trust_score:.0f}/100).")
            if decision == "BUY":
                decision = "WAIT"
                reasons.append("Downgraded from BUY to WAIT: long-term use with a low review-trust score warrants caution.")
        else:
            reasons.append("Intended for long-term use.")
    elif duration == "short_term":
        reasons.append("Intended for short-term use.")

    # --- Explainable AI Decision Card data: built only from real fields ---
    signals, warnings, missing = [], [], []
    if rating:
        signals.append(f"Average rating is {float(rating):.1f}/5.")
    if trust_score is not None:
        (signals if trust_score >= 60 else warnings).append(f"Review trust score is {trust_score:.0f}/100.")
    if fake_pct is not None:
        (warnings if fake_pct >= 25 else signals).append(f"{fake_pct:.0f}% of reviews look potentially fake.")
    for pro in (result.get("pros") or [])[:3]:
        signals.append(pro)
    for con in cons[:3]:
        warnings.append(con)
    if price is None:
        missing.append("Price could not be found on the product page.")
    if not review.get("features", {}).get("review_count") and not product.get("review_count"):
        missing.append("No customer reviews were available to analyze.")
    if result.get("analysis_method") == "selenium":
        missing.append("Selenium mode uses only 4 page-level features (price, rating, rating count, positive-review %); it does not run fake-review or trust scoring.")

    priority_explanation = None
    if priority:
        priority_explanation = reasons[0] if reasons else f"Priority set to {priority}, but no specific evidence for it was found."

    result["decision_raw"] = decision_raw
    result["decision"] = decision
    result["explain"] = {
        "final_recommendation": decision,
        "signals": signals,
        "warnings": warnings,
        "missing": missing,
        "priority_explanation": priority_explanation,
    }
    result["personalization"] = {
        "priority": priority,
        "duration": duration,
        "personal_recommendation": decision,
        "decision_raw": decision_raw,
        "reasons": reasons,
    }
    return result
