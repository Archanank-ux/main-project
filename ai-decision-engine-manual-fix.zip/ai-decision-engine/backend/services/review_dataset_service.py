"""Optional local review-dataset adapter.

If a product is present in backend/data/*.csv, its review text is merged with
reviews collected from the product page. This lets the project use the user's
cleaned review dataset while still supporting other products through live
page/Selenium reviews.
"""
from pathlib import Path
import re
import pandas as pd

DATA_DIR = Path(__file__).resolve().parents[1] / "data"


def _norm(value):
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def _load_files():
    if not DATA_DIR.exists():
        return []
    frames = []
    for path in DATA_DIR.glob("*.csv"):
        try:
            df = pd.read_csv(path, encoding="latin1", on_bad_lines="skip")
            if not df.empty:
                frames.append(df)
        except Exception:
            continue
    return frames


def reviews_for_product(product_name):
    target = _norm(product_name)
    if not target:
        return []
    matches = []
    for df in _load_files():
        product_col = next((c for c in df.columns if str(c).lower() in {"product_name", "productname", "product"}), None)
        if not product_col:
            continue
        for _, row in df.iterrows():
            name = str(row.get(product_col, ""))
            if not name:
                continue
            norm_name = _norm(name)
            if target == norm_name or target in norm_name or norm_name in target:
                review = str(row.get("Review", "") or "").strip()
                summary = str(row.get("Summary", "") or "").strip()
                text = " ".join(x for x in [review, summary] if x and x.lower() != "nan")
                if not text:
                    continue
                try:
                    rating = float(row.get("Rate")) if pd.notna(row.get("Rate")) else None
                except Exception:
                    rating = None
                matches.append({
                    "text": text[:4000],
                    "rating": rating,
                    "helpful_votes": 0,
                    "photos": 0,
                    "author": "Dataset",
                    "source": "local_review_dataset",
                })
    return matches


def enrich_product(product):
    """Merge matching local-dataset reviews into a normalized product."""
    dataset_reviews = reviews_for_product(product.get("name", ""))
    if not dataset_reviews:
        return product

    existing = product.get("reviews") or []
    # Dataset reviews are primary when a matching product is found. Keep a few
    # live reviews too so the UI can still reflect the current page.
    merged = dataset_reviews[:200] + existing[:50]
    product = dict(product)
    product["reviews"] = merged
    product["review_count"] = max(int(product.get("review_count") or 0), len(dataset_reviews))

    dataset_ratings = [r["rating"] for r in dataset_reviews if r.get("rating") is not None]
    if dataset_ratings:
        product["rating"] = sum(dataset_ratings) / len(dataset_ratings)

    return product
