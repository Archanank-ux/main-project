import json
from datetime import datetime
from database import db


class Analysis(db.Model):
    __tablename__ = "analyses"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)

    product_url = db.Column(db.String(1000), nullable=False)
    product_name = db.Column(db.String(255), nullable=True)
    category = db.Column(db.String(120), nullable=True)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Float, nullable=True)
    additional_details = db.Column(db.Text, nullable=True)

    result_json = db.Column(db.Text, nullable=False)  # serialized analysis result
    status = db.Column(db.String(30), default="completed")  # completed / failed

    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    @property
    def result(self) -> dict:
        return json.loads(self.result_json) if self.result_json else {}

    @result.setter
    def result(self, value: dict) -> None:
        self.result_json = json.dumps(value)

    def to_dict(self, include_result: bool = True) -> dict:
        data = {
            "id": self.id,
            "product_url": self.product_url,
            "product_name": self.product_name,
            "category": self.category,
            "description": self.description,
            "price": self.price,
            "additional_details": self.additional_details,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
        if include_result:
            data["result"] = self.result
        return data
