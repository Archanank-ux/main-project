from datetime import datetime
from database import db


class Feedback(db.Model):
    __tablename__ = "feedback"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    analysis_id = db.Column(db.Integer, db.ForeignKey("analyses.id"), nullable=True, index=True)

    helpful = db.Column(db.Boolean, nullable=False)
    explanation_clear = db.Column(db.Boolean, nullable=False)
    rating = db.Column(db.Integer, nullable=True)  # 1-5
    comment = db.Column(db.Text, nullable=True)
    category = db.Column(db.String(60), nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "analysis_id": self.analysis_id,
            "helpful": self.helpful,
            "explanation_clear": self.explanation_clear,
            "rating": self.rating,
            "comment": self.comment,
            "category": self.category,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
