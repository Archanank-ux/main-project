import re

from utils.platform import validate_platform_url

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
URL_RE = re.compile(r"^https?://[^\s/$.?#].[^\s]*$", re.IGNORECASE)
VALID_PRIORITIES = {"quality", "price", "durability"}
VALID_DURATIONS = {"short_term", "long_term"}


def is_valid_email(email: str) -> bool:
    return bool(email) and bool(EMAIL_RE.match(email.strip()))


def is_valid_url(url: str) -> bool:
    return bool(url) and bool(URL_RE.match(url.strip()))


def validate_password(password: str) -> list:
    """Returns a list of unmet requirement messages; empty list = valid."""
    errors = []
    if not password or len(password) < 8:
        errors.append("Password must be at least 8 characters long.")
    if not re.search(r"[A-Z]", password or ""):
        errors.append("Password must contain at least one uppercase letter.")
    if not re.search(r"[a-z]", password or ""):
        errors.append("Password must contain at least one lowercase letter.")
    if not re.search(r"\d", password or ""):
        errors.append("Password must contain at least one number.")
    return errors


def validate_registration(data: dict) -> dict:
    """Returns a dict of {field: message} for any invalid fields."""
    errors = {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    password = data.get("password") or ""
    confirm = data.get("confirm_password") or data.get("confirmPassword") or ""

    if len(name) < 2:
        errors["name"] = "Full name must be at least 2 characters."
    if not is_valid_email(email):
        errors["email"] = "Please enter a valid email address."
    pw_errors = validate_password(password)
    if pw_errors:
        errors["password"] = " ".join(pw_errors)
    if password != confirm:
        errors["confirm_password"] = "Passwords do not match."
    return errors


def validate_analysis_request(data: dict) -> dict:
    errors = {}
    url = (data.get("url") or data.get("product_url") or "").strip()

    if not url:
        errors["url"] = "Product URL is required."
    elif not is_valid_url(url):
        errors["url"] = "Please enter a valid product URL (e.g. https://example.com/product)."
    else:
        try:
            validate_platform_url(url)
        except ValueError as exc:
            errors["url"] = str(exc)

    method = (data.get("analysis_method") or "manual").lower()
    if method not in {"manual", "selenium"}:
        errors["analysis_method"] = "Analysis method must be manual or selenium."

    priority = (data.get("priority") or "").strip().lower()
    if priority not in VALID_PRIORITIES:
        errors["priority"] = "Please select a priority: Quality, Price, or Durability."

    duration = (data.get("duration") or "").strip().lower()
    if duration not in VALID_DURATIONS:
        errors["duration"] = "Please select how long you plan to use this product."

    second_url = (data.get("second_url") or "").strip()
    if second_url:
        if not is_valid_url(second_url):
            errors["second_url"] = "Please enter a valid second product URL."
        else:
            try:
                validate_platform_url(second_url)
            except ValueError as exc:
                errors["second_url"] = str(exc)
        if second_url and url and second_url.strip().lower() == url.strip().lower():
            errors["second_url"] = "The second URL is identical to the first product URL."

    return errors
