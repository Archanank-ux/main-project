"""
Centralized, SSRF-safe, multi-platform product URL validation.

Supported platforms: Amazon, Flipkart, Myntra, Meesho, Croma, Nykaa.
Validation is hostname-based (never a substring check), rejects anything
that is not plain http/https, and refuses URLs whose hostname resolves to
a private, loopback, link-local or otherwise non-public IP address so a
request can't be used to reach internal infrastructure.
"""
import ipaddress
import socket
from urllib.parse import urlparse

PLATFORM_DOMAINS = {
    "amazon": ["amazon.in", "amazon.com"],
    "flipkart": ["flipkart.com"],
    "myntra": ["myntra.com"],
    "meesho": ["meesho.com"],
    "croma": ["croma.com"],
    "nykaa": ["nykaa.com"],
}


def _host_matches(host: str, domain: str) -> bool:
    return host == domain or host.endswith("." + domain)


def detect_platform(url: str):
    """Return the platform key for a URL's hostname, or None if unsupported."""
    try:
        host = (urlparse(url).netloc or "").lower().split(":")[0]
    except Exception:
        return None
    if not host:
        return None
    for platform, domains in PLATFORM_DOMAINS.items():
        for domain in domains:
            if _host_matches(host, domain):
                return platform
    return None


def _is_public_ip(ip_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    return not (
        ip.is_private or ip.is_loopback or ip.is_link_local
        or ip.is_reserved or ip.is_multicast or ip.is_unspecified
    )


def validate_platform_url(url: str) -> str:
    """Validate a product URL and return its platform key.

    Raises ValueError with a clear, user-facing message on any failure:
    bad scheme, unsupported/unknown platform, or a hostname that does not
    resolve to a public IP address (SSRF protection).
    """
    if not url or not url.strip():
        raise ValueError("Product URL is required.")
    url = url.strip()

    try:
        parsed = urlparse(url)
    except Exception:
        raise ValueError("Please enter a valid product URL.")

    if parsed.scheme not in {"http", "https"}:
        raise ValueError("Only http/https product URLs are supported.")

    host = (parsed.netloc or "").lower().split(":")[0]
    if not host:
        raise ValueError("Please enter a valid product URL.")

    platform = detect_platform(url)
    if not platform:
        supported = ", ".join(sorted({d for domains in PLATFORM_DOMAINS.values() for d in domains}))
        raise ValueError(
            f"This platform is not supported yet. Supported platforms: Amazon, Flipkart, "
            f"Myntra, Meesho, Croma, Nykaa ({supported})."
        )

    try:
        resolved_ips = socket.getaddrinfo(host, None)
    except socket.gaierror:
        raise ValueError("Could not resolve the product URL's host. Please check the URL.")

    ip_addresses = {info[4][0] for info in resolved_ips}
    if not ip_addresses or not any(_is_public_ip(ip) for ip in ip_addresses):
        raise ValueError("This URL is not reachable as a public product page.")

    return platform


def platforms_supported_live() -> dict:
    """Honest capability map: which platforms can actually be fetched here.

    Only Amazon has a working scraper/Selenium path wired up in this
    build. The others are validated and normalized but not yet scraped,
    so we never claim to have data for them.
    """
    return {
        "amazon": True,
        "flipkart": False,
        "myntra": False,
        "meesho": False,
        "croma": False,
        "nykaa": False,
    }
