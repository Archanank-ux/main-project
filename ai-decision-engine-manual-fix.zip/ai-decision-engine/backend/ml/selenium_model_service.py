"""Small 4-feature decision model used only by Selenium analysis.

This model is intentionally separate from the existing 12-feature Manual model.
The original Manual model files are not modified.
"""
from pathlib import Path
import joblib
import pandas as pd


class SeleniumModelService:
    def __init__(self):
        base = Path(__file__).resolve().parent
        self.model = joblib.load(base / "selenium_buy_wait_skip_model.joblib")

    @property
    def feature_names(self):
        return list(self.model.feature_names_in_)

    def predict(self, features):
        row = pd.DataFrame([[float(features[name]) for name in self.feature_names]], columns=self.feature_names)
        decision = str(self.model.predict(row)[0])
        confidence = None
        if hasattr(self.model, "predict_proba"):
            confidence = float(self.model.predict_proba(row)[0].max())
        return {"decision": decision, "confidence": confidence}


selenium_model_service = SeleniumModelService()
