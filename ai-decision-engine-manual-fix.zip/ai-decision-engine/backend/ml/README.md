# ML models

## Manual Analysis
Manual mode keeps the original trained files unchanged:
- `buy_wait_skip_model.joblib` — 12-feature BUY/WAIT/SKIP model
- `buy_wait_skip_encoder.joblib` — decision label encoder
- `fake_review_model.joblib` + `fake_review_vectorizer.joblib` — fake-review detection

Manual mode performs the deep review-trust pipeline, including fake-review filtering, rating distribution, pros/cons evidence and review trust.

## Selenium Analysis
Selenium mode is intentionally separate and small. It uses:
- `selenium_buy_wait_skip_model.joblib` — separate 4-feature BUY/WAIT/SKIP model

The four Selenium features are:
1. `price`
2. `rating`
3. `rating_count`
4. `positive_review_pct`

The Selenium model is a lightweight prototype model trained on generated value/rating/review-signal examples. It does not modify or replace the original Manual model.
