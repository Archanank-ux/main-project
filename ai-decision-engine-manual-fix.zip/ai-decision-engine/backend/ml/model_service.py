"""
Live ML inference for the AI Product Decision Engine.

This service loads the supplied BUY/WAIT/SKIP model and the supplied
fake-review classifier. The BUY/WAIT/SKIP model expects exactly 12
review-derived features in the order stored in feature_names_in_.
"""

import os
import joblib
import numpy as np
import pandas as pd


class MLModelService:
    def __init__(self):
        base = os.path.dirname(os.path.abspath(__file__))
        self.decision_path = os.path.join(base, "buy_wait_skip_model.joblib")
        self.encoder_path = os.path.join(base, "buy_wait_skip_encoder.joblib")
        self.fake_model_path = os.path.join(base, "fake_review_model.joblib")
        self.fake_vectorizer_path = os.path.join(base, "fake_review_vectorizer.joblib")

        self.model = None
        self.encoder = None
        self.fake_model = None
        self.fake_vectorizer = None
        self.load_model()

    def load_model(self):
        self.model = joblib.load(self.decision_path)
        self.encoder = joblib.load(self.encoder_path)
        self.fake_model = joblib.load(self.fake_model_path)
        self.fake_vectorizer = joblib.load(self.fake_vectorizer_path)

    @property
    def feature_names(self):
        return list(self.model.feature_names_in_)

    def predict_fake_reviews(self, reviews):
        """Return fake probability for each review.

        The uploaded classifier has classes [0, 1]. We treat class 1 as
        the fake class by default; override FAKE_CLASS in the environment
        if the original training labels used the opposite convention.
        """
        if not reviews:
            return []
        texts = [str(r.get("text") or "") for r in reviews]
        X = self.fake_vectorizer.transform(texts)
        probs = self.fake_model.predict_proba(X)
        classes = list(self.fake_model.classes_)
        fake_class = int(os.environ.get("FAKE_CLASS", "1"))
        if fake_class in classes:
            idx = classes.index(fake_class)
        else:
            idx = int(np.argmax(classes))
        return [float(p[idx]) for p in probs]

    def predict_decision(self, features):
        row = [float(features[name]) for name in self.feature_names]
        X = pd.DataFrame([row], columns=self.feature_names)
        encoded = self.model.predict(X)
        decision = self.encoder.inverse_transform(encoded)[0]

        confidence = None
        if hasattr(self.model, "predict_proba"):
            probs = self.model.predict_proba(X)[0]
            confidence = float(np.max(probs))

        return {
            "decision": str(decision),
            "confidence": confidence,
        }


ml_model_service = MLModelService()
