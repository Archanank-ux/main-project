from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from utils.validators import validate_analysis_request
from services import analysis_service
from services.product_analysis_service import collect_manual

analysis_bp = Blueprint("analysis", __name__, url_prefix="/api/analysis")


@analysis_bp.post("/product-preview")
@jwt_required()
def product_preview():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    if not url:
        return jsonify({"success": False, "message": "Amazon product URL is required."}), 400
    try:
        product = collect_manual(url)
        # Preview is only for displaying the fetched product details.
        # The trained ML models are not run until the user clicks Analyze.
        product.pop("reviews", None)
        return jsonify({"success": True, "product": product}), 200
    except Exception as exc:
        return jsonify({"success": False, "message": str(exc) or "Could not fetch product details."}), 400


@analysis_bp.post("/analyze")
@jwt_required()
def analyze():
    user_id = int(get_jwt_identity())
    data = request.get_json(silent=True) or {}

    errors = validate_analysis_request(data)
    if errors:
        return jsonify({"success": False, "errors": errors}), 400

    try:
        analysis = analysis_service.run_analysis(user_id, data)
    except Exception as exc:
        # Keep scraper/Selenium failures readable for the UI.
        return jsonify({
            "success": False,
            "message": str(exc) or "Product analysis failed. Please try the other analysis method."
        }), 400

    return jsonify({"success": True, "analysis": analysis.to_dict()}), 201


@analysis_bp.post("/compare")
@jwt_required()
def compare():
    user_id = int(get_jwt_identity())
    data = request.get_json(silent=True) or {}

    if not (data.get("second_url") or "").strip():
        return jsonify({"success": False, "errors": {"second_url": "A second product URL is required to compare."}}), 400

    errors = validate_analysis_request(data)
    if errors:
        return jsonify({"success": False, "errors": errors}), 400

    try:
        analysis = analysis_service.compare_products(user_id, data)
    except Exception as exc:
        return jsonify({
            "success": False,
            "message": str(exc) or "Product comparison failed. Please try again."
        }), 400

    return jsonify({"success": True, "analysis": analysis.to_dict()}), 201


@analysis_bp.get("/history")
@jwt_required()
def history():
    user_id = int(get_jwt_identity())
    records = analysis_service.get_user_history(user_id)
    return jsonify({"success": True, "history": [a.to_dict(include_result=False) for a in records]}), 200


@analysis_bp.get("/stats")
@jwt_required()
def stats():
    user_id = int(get_jwt_identity())
    return jsonify({"success": True, "stats": analysis_service.get_user_stats(user_id)}), 200


@analysis_bp.get("/<int:analysis_id>")
@jwt_required()
def get_one(analysis_id):
    user_id = int(get_jwt_identity())
    analysis = analysis_service.get_user_analysis(user_id, analysis_id)
    if not analysis:
        return jsonify({"success": False, "message": "Analysis not found."}), 404
    return jsonify({"success": True, "analysis": analysis.to_dict()}), 200


@analysis_bp.delete("/<int:analysis_id>")
@jwt_required()
def delete_one(analysis_id):
    user_id = int(get_jwt_identity())
    deleted = analysis_service.delete_user_analysis(user_id, analysis_id)
    if not deleted:
        return jsonify({"success": False, "message": "Analysis not found."}), 404
    return jsonify({"success": True, "message": "Analysis deleted."}), 200
