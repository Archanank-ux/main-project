from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from database import db
from models.feedback import Feedback
from models.analysis import Analysis

feedback_bp = Blueprint("feedback", __name__, url_prefix="/api/feedback")


def _validate(data: dict) -> dict:
    errors = {}
    if "helpful" not in data or not isinstance(data.get("helpful"), bool):
        errors["helpful"] = "Please answer whether this was helpful."
    if "explanation_clear" not in data or not isinstance(data.get("explanation_clear"), bool):
        errors["explanation_clear"] = "Please answer whether the explanation was clear."
    rating = data.get("rating")
    if rating not in (None, ""):
        try:
            if not (1 <= int(rating) <= 5):
                raise ValueError()
        except (TypeError, ValueError):
            errors["rating"] = "Rating must be a number from 1 to 5."
    return errors


@feedback_bp.post("")
@jwt_required()
def submit_feedback():
    user_id = int(get_jwt_identity())
    data = request.get_json(silent=True) or {}

    errors = _validate(data)
    if errors:
        return jsonify({"success": False, "errors": errors}), 400

    analysis_id = data.get("analysis_id")
    if analysis_id is not None:
        analysis = Analysis.query.filter_by(id=analysis_id, user_id=user_id).first()
        if not analysis:
            return jsonify({"success": False, "message": "That analysis could not be found."}), 404

        existing = Feedback.query.filter_by(user_id=user_id, analysis_id=analysis_id).first()
        if existing:
            return jsonify({"success": False, "message": "You already submitted feedback for this analysis.", "duplicate": True}), 409

    feedback = Feedback(
        user_id=user_id,
        analysis_id=analysis_id,
        helpful=bool(data.get("helpful")),
        explanation_clear=bool(data.get("explanation_clear")),
        rating=int(data["rating"]) if data.get("rating") not in (None, "") else None,
        comment=(data.get("comment") or "").strip()[:2000] or None,
        category=(data.get("category") or "").strip()[:60] or None,
    )

    try:
        db.session.add(feedback)
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({"success": False, "message": "Could not save feedback. Please try again."}), 500

    return jsonify({"success": True, "feedback": feedback.to_dict()}), 201
