from datetime import datetime
import os
from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from database import db
from models.user import User
from models.analysis import Analysis

admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')

ADMIN_EMAIL = os.environ.get('ADMIN_EMAIL', 'admin@aidecision.local').strip().lower()
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'Admin@123')


def _require_admin():
    identity = get_jwt_identity()
    return isinstance(identity, str) and identity.startswith('admin:')


@admin_bp.post('/login')
def admin_login():
    data = request.get_json(silent=True) or {}
    email = (data.get('email') or '').strip().lower()
    password = data.get('password') or ''
    if email != ADMIN_EMAIL or password != ADMIN_PASSWORD:
        return jsonify({'success': False, 'message': 'Invalid admin credentials.'}), 401
    token = create_access_token(identity=f'admin:{email}')
    return jsonify({'success': True, 'access_token': token, 'admin': {'email': email}}), 200


@admin_bp.get('/overview')
@jwt_required()
def overview():
    if not _require_admin():
        return jsonify({'success': False, 'message': 'Admin access required.'}), 403

    users = User.query.order_by(User.created_at.desc()).all()
    analyses = Analysis.query.order_by(Analysis.created_at.desc()).limit(100).all()
    return jsonify({
        'success': True,
        'stats': {
            'users': User.query.count(),
            'analyses': Analysis.query.count(),
            'completed': Analysis.query.filter_by(status='completed').count(),
        },
        'users': [
            {'id': u.id, 'name': u.name, 'email': u.email,
             'created_at': u.created_at.isoformat() if u.created_at else None,
             'analysis_count': u.analyses.count()}
            for u in users
        ],
        'analyses': [
            {'id': a.id, 'user_name': a.user.name if a.user else 'Unknown',
             'product_name': a.product_name or '', 'method': (a.result or {}).get('analysis_method', 'manual'),
             'decision': (a.result or {}).get('decision', '—'),
             'created_at': a.created_at.isoformat() if a.created_at else None}
            for a in analyses
        ],
    }), 200


@admin_bp.get('/logs')
@jwt_required()
def logs():
    if not _require_admin():
        return jsonify({'success': False, 'message': 'Admin access required.'}), 403
    log_path = os.environ.get('APP_LOG_FILE', os.path.join(os.path.dirname(os.path.dirname(__file__)), 'app.log'))
    if not os.path.exists(log_path):
        return jsonify({'success': True, 'path': log_path, 'content': 'No log file has been created yet.'}), 200
    try:
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()[-20000:]
    except OSError as exc:
        return jsonify({'success': False, 'message': str(exc)}), 500
    return jsonify({'success': True, 'path': log_path, 'content': content}), 200
