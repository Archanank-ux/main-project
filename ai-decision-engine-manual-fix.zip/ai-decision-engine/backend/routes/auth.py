from flask import Blueprint, request, jsonify
from flask_jwt_extended import (
    create_access_token, jwt_required, get_jwt_identity, get_jwt
)

from database import db
from models.user import User
from utils.validators import validate_registration, is_valid_email

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")

# In-memory blocklist for logged-out tokens (fine for a single dev process;
# swap for Redis/DB-backed storage in production).
_revoked_tokens = set()


@auth_bp.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    errors = validate_registration(data)
    if errors:
        return jsonify({"success": False, "errors": errors}), 400

    email = data["email"].strip().lower()
    if User.query.filter_by(email=email).first():
        return jsonify({"success": False, "errors": {"email": "An account with this email already exists."}}), 400

    user = User(name=data["name"].strip(), email=email)
    user.set_password(data["password"])
    db.session.add(user)
    db.session.commit()

    return jsonify({"success": True, "user": user.to_public_dict()}), 201


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not is_valid_email(email) or not password:
        return jsonify({"success": False, "message": "Email and password are required."}), 400

    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        return jsonify({"success": False, "message": "Invalid email or password."}), 401

    token = create_access_token(identity=str(user.id))
    return jsonify({"success": True, "access_token": token, "user": user.to_public_dict()}), 200


@auth_bp.get("/me")
@jwt_required()
def me():
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not user:
        return jsonify({"success": False, "message": "User not found."}), 404
    return jsonify({"success": True, "user": user.to_public_dict()}), 200


@auth_bp.post("/logout")
@jwt_required()
def logout():
    jti = get_jwt()["jti"]
    _revoked_tokens.add(jti)
    return jsonify({"success": True, "message": "Logged out."}), 200


def is_token_revoked(jwt_header, jwt_payload) -> bool:
    return jwt_payload["jti"] in _revoked_tokens
