# Review dataset

Place cleaned review CSV files in this folder.

Supported columns for matching:
- `Product_name` / `Product Name` / `product_name`
- `Review`
- `Summary`
- `Rate`

When the product name matches a row in a local CSV, those reviews are merged
into the analysis and used for Review Trust Score, Pros and Cons, and the
BUY/WAIT/SKIP model features. Other products continue to use reviews collected
from the product page.
