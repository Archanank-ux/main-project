from flask import Flask, jsonify
import logging
import os
from flask_cors import CORS
from flask_jwt_extended import JWTManager

from config import Config
from database import db


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    log_file = os.environ.get("APP_LOG_FILE", os.path.join(os.path.dirname(__file__), "app.log"))
    logging.basicConfig(filename=log_file, level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")

    db.init_app(app)
    CORS(app, resources={r"/api/*": {"origins": Config.CORS_ORIGINS}}, supports_credentials=True)

    jwt = JWTManager(app)

    from routes.auth import auth_bp, is_token_revoked
    from routes.analysis import analysis_bp
    from routes.health import health_bp
    from routes.admin import admin_bp
    from routes.feedback import feedback_bp

    jwt.token_in_blocklist_loader(is_token_revoked)

    app.register_blueprint(auth_bp)
    app.register_blueprint(analysis_bp)
    app.register_blueprint(health_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(feedback_bp)

    # ── Error handlers — never leak stack traces to the client ──────────
    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"success": False, "message": "Resource not found."}), 404

    @app.errorhandler(401)
    def unauthorized(e):
        return jsonify({"success": False, "message": "Please log in to continue."}), 401

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception(e)
        return jsonify({"success": False, "message": "Something went wrong. Please try again."}), 500

    @jwt.unauthorized_loader
    def missing_token(reason):
        return jsonify({"success": False, "message": "Please log in to continue."}), 401

    @jwt.invalid_token_loader
    def invalid_token(reason):
        return jsonify({"success": False, "message": "Please log in to continue."}), 401

    @jwt.expired_token_loader
    def expired_token(jwt_header, jwt_payload):
        return jsonify({"success": False, "message": "Your session has expired. Please log in again."}), 401

    @jwt.revoked_token_loader
    def revoked_token(jwt_header, jwt_payload):
        return jsonify({"success": False, "message": "Please log in to continue."}), 401

    with app.app_context():
        db.create_all()

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
